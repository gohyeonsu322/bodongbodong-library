export const quantityText = game => `${game.quantity ?? 1}개`;
export const scoreText = (value,maximum) => value == null ? '정보 없음' : `${value} / ${maximum}`;
export function photoAndDifficulty(game,link,escape) {
  const credit = game.imageCredit || '보동보동';
  const photo = game.image ? `<li>사진: ${game.imageSource ? link(game.imageSource,escape(credit)) : escape(credit)}</li>` : '';
  return `<details class="source-details"><summary>사진 출처 · 난이도 분류</summary><ul>${photo}<li>난이도 분류: 1.5 미만 입문 / 2 미만 초급 / 3 미만 중급 / 4 미만 고급 / 4 이상 전문가</li></ul></details>`;
}
