export const UNKNOWN_LOCATION='위치 확인 필요';
export const AVAILABILITY={available:'정상 이용 가능',check:'부품 확인 필요',repair:'파손·수리 중',loaned:'대여 중'};
export const locationText=game=>typeof game?.location==='string'&&game.location.trim()?game.location.trim():UNKNOWN_LOCATION;
export const availability=game=>Object.hasOwn(AVAILABILITY,game?.availability)?game.availability:'available';
export const availabilityText=game=>AVAILABILITY[availability(game)];
export const EDITION_LANGUAGES={ko:'한국어판 (별도 표시 없음)',en:'영어판',zh:'중국어판',ja:'일본어판',de:'독일어판',other:'기타 외국어판'};
export function editionLanguage(game){
 if(Object.hasOwn(EDITION_LANGUAGES,game?.editionLanguage))return game.editionLanguage;
 const name=String(game?.name||'').normalize('NFKC');
 if(/중국(?:어)?판|중문판|\((?:중국어|중문)\)/.test(name))return 'zh';
 if(/영어판|영문판|\(영문\)/.test(name))return 'en';
 if(/일본어판|일문판|\(일본어|\(일문\)/.test(name))return 'ja';
 if(/독일어판|독어판|\(독일어\)/.test(name))return 'de';
 return 'ko';
}
export function foreignEditionText(game){
 const code=editionLanguage(game);
 return code==='ko'?'':code==='other'?(String(game.editionLanguageName||'').trim()||'외국어판'):EDITION_LANGUAGES[code];
}
export const ISSUE_FILTERS=[
 {id:'location',label:'위치 확인 필요'},
 {id:'photos',label:'사진 없음'},
 {id:'people',label:'인원 정보 없음'},
 {id:'time',label:'시간 정보 없음'},
 {id:'difficulty',label:'난이도 정보 없음'},
 {id:'review',label:'이름·판본 확인 필요'}
];
export function matchesIssue(game,id){
 if(id==='location')return locationText(game)===UNKNOWN_LOCATION;
 if(id==='photos')return !game.image&&!(game.gallery||[]).some(photo=>photo?.image);
 if(id==='people')return game.minPlayers==null||game.maxPlayers==null;
 if(id==='time')return game.minutes==null;
 if(id==='difficulty')return game.weight==null;
 if(id==='review')return Boolean(game.needsReview);
 return true;
}
export function issueCounts(games=[]){return Object.fromEntries(ISSUE_FILTERS.map(item=>[item.id,games.filter(game=>matchesIssue(game,item.id)).length]));}
