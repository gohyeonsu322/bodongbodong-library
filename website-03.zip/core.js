export const GENRES = ['파티','전략','협력','추리·심리','퍼즐·추상','순발력','카드','경제·협상','테마·모험'];
export const normalize = (value='') => String(value).normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]/gu,'');
const CHO = ['ㄱ','ㄲ','ㄴ','ㄷ','ㄸ','ㄹ','ㅁ','ㅂ','ㅃ','ㅅ','ㅆ','ㅇ','ㅈ','ㅉ','ㅊ','ㅋ','ㅌ','ㅍ','ㅎ'];
const initials = s => [...s].map(ch=>{const n=ch.charCodeAt(0)-0xAC00;return n>=0&&n<11172?CHO[Math.floor(n/588)]:ch;}).join('');
export function difficulty(weight) {
  if (weight==null) return {label:'정보 확인 중',level:0};
  if (weight<1.5) return {label:'입문',level:1};
  if (weight<2) return {label:'초급',level:2};
  if (weight<3) return {label:'중급',level:3};
  if (weight<4) return {label:'고급',level:4};
  return {label:'전문가',level:5};
}
export function playersText(g) {
  if (g.minPlayers==null||g.maxPlayers==null) return '인원 확인 중';
  return (g.minPlayers===g.maxPlayers?g.minPlayers:`${g.minPlayers}–${g.maxPlayers}`)+'인';
}
export function timeText(g) {
  if (!g.minutes) return '시간 확인 중';
  if (g.timeText&&g.timeText!=='-') return g.timeText.replace(/\s+/g,' ').replace(' 이하',' 이내');
  return `${g.minutes}분`;
}
export function matches(g,f={},favorites=[]) {
  if (f.search) {
    const terms=f.search.trim().split(/\s+/).map(normalize).filter(Boolean);
    const corpus=normalize([g.name,g.english,...(g.aliases||[]),...(g.genres||[]),...(g.mechanics||[])].join(' '));
    const cho=normalize(initials(g.name));
    if (!terms.every(t=>corpus.includes(t)||cho.includes(t))) return false;
  }
  if (f.genre&&f.genre!=='all'&&!g.genres.includes(f.genre)) return false;
  if (f.people) {
    const n=Number(f.people);
    if (g.minPlayers==null||g.maxPlayers==null||n<g.minPlayers||n>g.maxPlayers) return false;
  }
  if (f.time&&(g.minutes==null||g.timeMode==='minimum'||g.minutes>Number(f.time))) return false;
  if (f.level&&(!g.weight||difficulty(g.weight).level!==Number(f.level))) return false;
  if (f.baseOnly&&g.kind==='expansion') return false;
  if (f.photosOnly&&!g.image) return false;
  if (f.view==='favorites'&&!favorites.includes(g.id)) return false;
  if (f.view==='beginner'&&(g.weight==null||g.weight>=2||g.kind==='expansion')) return false;
  if (f.view==='duo'&&(g.minPlayers==null||g.minPlayers>2||g.maxPlayers<2||g.kind==='expansion')) return false;
  if (f.view==='group'&&(g.maxPlayers==null||g.maxPlayers<6||g.kind==='expansion')) return false;
  if (f.view==='strategy'&&!g.genres.includes('전략')) return false;
  return true;
}
export function selectGames(games,f={},favorites=[]) {
  const result=games.filter(g=>matches(g,f,favorites));
  result.sort((a,b)=>{
    let d=0;
    if (f.sort==='time') d=(a.minutes??Infinity)-(b.minutes??Infinity);
    else if (f.sort==='easy') d=(a.weight??Infinity)-(b.weight??Infinity);
    else if (f.sort==='rating') d=(b.rating??-1)-(a.rating??-1);
    return d||a.name.localeCompare(b.name,'ko');
  });
  return result;
}
export function randomCandidates(games,f={},favorites=[]) {
  return selectGames(games,f,favorites).filter(g=>g.kind!=='expansion'&&!g.needsReview&&g.minPlayers!=null&&g.maxPlayers!=null&&g.description);
}
export function catalogFromImport(value) {
  if (!value||!Array.isArray(value.games)||!value.games.length) throw new Error('games 배열이 있는 목록 JSON 파일을 선택해 주세요.');
  if (value.games.length>3000) throw new Error('한 번에 3,000종까지 가져올 수 있어요.');
  const ids=new Set();
  for (const g of value.games) {
    if (!g||typeof g!=='object'||typeof g.id!=='string'||!g.id.trim()||typeof g.name!=='string'||!g.name.trim()||!Array.isArray(g.genres)||!g.genres.length||!g.genres.every(x=>typeof x==='string')||!Array.isArray(g.mechanics)||!g.mechanics.every(x=>typeof x==='string')) throw new Error('게임의 id·이름·장르·메커니즘을 확인해 주세요.');
    if (ids.has(g.id)) throw new Error('게임 id가 중복되어 있어요.');
    ids.add(g.id);
    for (const key of ['minPlayers','maxPlayers','minutes','weight','rating','quantity']) if (g[key]!=null&&(!Number.isFinite(g[key])||g[key]<0)) throw new Error(`${g.name}: 숫자 정보를 확인해 주세요.`);
    for (const key of ['minPlayers','maxPlayers','minutes','quantity']) if (g[key]!=null&&(!Number.isInteger(g[key])||g[key]<1)) throw new Error(`${g.name}: 인원·시간·수량은 1 이상의 정수로 입력해 주세요.`);
    if (g.minPlayers!=null&&g.maxPlayers!=null&&g.minPlayers>g.maxPlayers) throw new Error(`${g.name}: 최소 인원이 최대 인원보다 커요.`);
    if (g.weight>5||g.rating>10) throw new Error(`${g.name}: 난이도는 5, 평점은 10을 넘을 수 없어요.`);
    g.aliases=Array.isArray(g.aliases)?g.aliases.filter(x=>typeof x==='string'):[];
    g.gallery=Array.isArray(g.gallery)?g.gallery.filter(x=>x&&typeof x==='object'&&typeof x.image==='string').map(x=>({...x,source:typeof x.source==='string'?x.source:'',credit:typeof x.credit==='string'?x.credit:''})):[];
    g.sourceRecords=Array.isArray(g.sourceRecords)?g.sourceRecords.filter(x=>x&&typeof x==='object'):[];
    g.sources=Array.isArray(g.sources)?g.sources.filter(x=>typeof x==='string'||(x&&typeof x==='object'&&typeof x.url==='string')):[];
    for(const key of ['english','description','best','baseGame','notes','image','imageSource','imageCredit','timeText']) if(typeof g[key]!=='string')g[key]='';
    if(!['base','expansion','standalone-expansion'].includes(g.kind))g.kind='base';
    if(!['minimum','maximum','approximate'].includes(g.timeMode))g.timeMode='approximate';
  }
  if(!value.meta||typeof value.meta!=='object'||Array.isArray(value.meta))value.meta={};
  return value;
}
