// Only explicit numbers and ranges count as confirmed recommended-player data.
export function recommendedPlayers(value='') {
 const source=String(value).normalize('NFKC').trim().replace(/[인명\s]/g,'').replace(/[~〜～–—−]/g,'-');
 if(!source||!/^\d+(?:-\d+)?(?:[,/·]\d+(?:-\d+)?)*$/.test(source))return [];
 const result=new Set();
 for(const part of source.split(/[,/·]/)){
  const [lo,hi=lo]=part.split('-').map(Number);
  if(lo<1||hi<lo||hi>1000)return [];
  for(let n=lo;n<=hi;n++)result.add(n);
 }
 return [...result].sort((a,b)=>a-b);
}
export const hasPlayerRange=g=>Number.isInteger(g?.minPlayers)&&Number.isInteger(g?.maxPlayers)&&g.minPlayers>=1&&g.maxPlayers>=g.minPlayers;
export function matchesPlayers(g,n,mode='possible'){
 n=Number(n);
 return hasPlayerRange(g)&&Number.isInteger(n)&&n>=g.minPlayers&&n<=g.maxPlayers&&(mode!=='recommended'||recommendedPlayers(g.best).includes(n));
}
