export const DEFAULT_CONDITIONS=[
 {id:'elimination',label:'중간 탈락 있음',description:'게임이 끝나기 전에 탈락하여 남은 진행에 참여하지 못하는 사람이 생길 수 있어요.',group:'참여 방식',active:true},
 {id:'bluffing',label:'거짓말·정체 숨기기 요소 있음',description:'자신의 정체나 가진 정보를 숨기거나, 다른 사람이 믿도록 거짓 정보를 전달하는 요소가 있어요.',group:'상호작용',active:true},
 {id:'talkative',label:'대화가 많은 편',description:'협의·협상·토론처럼 서로 말하며 진행하는 비중이 큰 게임이에요.',group:'상호작용',active:true},
 {id:'direct-attack',label:'직접 공격 요소가 많음',description:'다른 사람의 자원·말·점수 등을 직접 빼앗거나 방해하는 행동의 비중이 큰 게임이에요.',group:'상호작용',active:true},
 {id:'luck',label:'운의 영향이 큰 편',description:'주사위나 무작위 카드처럼 우연한 결과가 승패에 미치는 영향이 큰 편이에요.',group:'게임 성향',active:true}
];
export const CONDITION_STATES={unknown:'미확인',yes:'해당함',no:'해당 없음'};
const validId=value=>typeof value==='string'&&/^[-_a-zA-Z0-9]{1,100}$/.test(value);
const key=value=>value.normalize('NFKC').replace(/\s+/g,'').toLowerCase();
export function validateDefinitions(items){
 if(!Array.isArray(items)||items.length>100)throw new Error('조건은 100개까지 등록할 수 있어요.');
 const ids=new Set(),labels=new Set();
 return items.map(item=>{
  if(!item||!validId(item.id)||ids.has(item.id))throw new Error('조건 번호가 올바르지 않거나 중복돼요.');
  ids.add(item.id);
  const string=(name,max,required=false)=>{const value=item[name]??'';if(typeof value!=='string'||value.length>max||(required&&!value.trim())||/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value))throw new Error(`조건 ${name==='label'?'이름':name==='group'?'분류':'설명'}을 확인해 주세요. 최대 ${max}자까지 입력할 수 있어요.`);return value.trim();};
  const label=string('label',80,true),normalized=key(label);
  if(labels.has(normalized))throw new Error('같은 이름의 조건이 이미 있어요.');labels.add(normalized);
  if(typeof item.active!=='boolean')throw new Error('조건 사용 여부를 선택해 주세요.');
  return {id:item.id,label,description:string('description',1500,true),group:string('group',60),active:item.active};
 });
}
export function readConditions(catalog){
 const value=catalog?.conditionDefinitions;
 if(value==null)return {version:1,revision:0,items:DEFAULT_CONDITIONS.map(x=>({...x}))};
 if(value.version!==1||!Number.isSafeInteger(value.revision)||value.revision<0)throw new Error('조건 관리 자료 형식을 확인해 주세요.');
 return {version:1,revision:value.revision,items:validateDefinitions(value.items)};
}
export function gameConditions(game){
 const raw=game?.conditions;
 if(raw==null)return {};
 if(typeof raw!=='object'||Array.isArray(raw)||Object.keys(raw).length>100)throw new Error('게임별 조건 자료를 확인해 주세요.');
 const entries=[];
 for(const [id,state] of Object.entries(raw)){
  if(!validId(id)||!['yes','no','unknown'].includes(state))throw new Error('조건은 해당함·해당 없음·미확인 중 하나로 지정해 주세요.');
  if(state!=='unknown')entries.push([id,state]);
 }
 return Object.fromEntries(entries);
}
export function matchesConditions(game,selected={}){
 return Object.entries(selected).every(([id,wanted])=>!['yes','no'].includes(wanted)||game.conditions?.[id]===wanted);
}
export function conditionUsage(vault,id){
 const known=game=>['yes','no'].includes(game.conditions?.[id]);
 return {games:vault.state.catalog.games.filter(known).length,trash:vault.state.trash.filter(entry=>known(entry.game)).length};
}
export function changeCondition(vault,id,input,expectedRevision,operation='save',now=new Date().toISOString()){
 const current=readConditions(vault.state.catalog);
 if(!Number.isSafeInteger(expectedRevision)||expectedRevision!==current.revision)throw Object.assign(new Error('다른 화면에서 조건을 수정했어요. 작성한 내용을 복사한 뒤 최신 목록을 불러와 주세요.'),{status:409});
 const previous=current.items.find(item=>item.id===id);
 if(!validId(id)||(operation==='save'&&input?.id!==id))throw new Error('조건 정보를 확인해 주세요.');
 let items;
 if(operation==='delete'){
  if(!previous)throw new Error('조건을 찾지 못했어요.');
  const used=conditionUsage(vault,id);
  if(used.games||used.trash)throw new Error('게임이나 삭제 기록에 연결된 조건은 삭제할 수 없어요. 사용 중지를 선택하면 기존 기록을 유지할 수 있어요.');
  items=current.items.filter(item=>item.id!==id);
 }else items=validateDefinitions(previous?current.items.map(item=>item.id===id?input:item):[...current.items,input]);
 const next=structuredClone(vault);
 next.state.catalog.conditionDefinitions={version:1,revision:current.revision+1,items};
 next.state.catalog.meta.updatedAt=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(now));
 next.state.catalog.meta.updatedAtExact=now;next.updatedAt=now;
 return {vault:next,result:{condition:items.find(item=>item.id===id)||null,revision:current.revision+1}};
}
