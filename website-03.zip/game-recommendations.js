import {readGlossary,termIndex,termKey} from './glossary-model.js';
import {availability} from './library-state.js?v=20261031-discovery-v1';
import {matches} from './core.js?v=20261031-discovery-v1';

export function similarGames(source,catalog,filters={},limit=3){
 const index=termIndex(readGlossary(catalog).terms);
 const tags=(game,field)=>{
  const result=new Map();
  for(const name of game[field]||[]){
   const term=index.get(termKey(name)),normalized=termKey(name);
   if(!normalized||term?.category==='note'||/확인중|확인필요|미분류|정보없음/.test(normalized))continue;
   if(term&&term.category!==(field==='mechanics'?'mechanic':'genre'))continue;
   result.set(term?.id||'raw:'+normalized,term?.label||name);
  }
  return result;
 };
 const mechanics=tags(source,'mechanics'),genres=tags(source,'genres');
 if(!mechanics.size)return [];
 const overlap=(a,b)=>{const common=[...a.keys()].filter(id=>b.has(id));return {common,ratio:common.length/new Set([...a.keys(),...b.keys()]).size||0};};
 const known=value=>Number.isFinite(value)&&value>=0;
 const eligible={people:filters.people,time:filters.time,playerMode:filters.playerMode,conditions:filters.conditions,view:['duo','group'].includes(filters.view)?filters.view:'all'};
 const results=[];
 for(const game of catalog.games){
  if(game.id===source.id||game.kind==='expansion'||availability(game)!=='available'||!matches(game,eligible))continue;
  const m=overlap(mechanics,tags(game,'mechanics'));if(!m.common.length)continue;
  const genreTags=tags(game,'genres'),g=overlap(genres,genreTags);
  let earned=60*m.ratio,possible=60;
  if(genres.size&&genreTags.size){earned+=20*g.ratio;possible+=20;}
  const reasons=[`같은 방식: ${m.common.map(id=>mechanics.get(id)).slice(0,2).join(' · ')}`];
  let difference=null;
  if(known(source.weight)&&known(game.weight)){
   difference=Math.abs(source.weight-game.weight);if(difference>1.5)continue;
   possible+=15;earned+=difference<=0.5?15:difference<=1?8:0;
   if(difference<=0.5)reasons.push('난이도가 비슷해요');
  }
  if(known(source.minutes)&&known(game.minutes)&&source.timeMode!=='minimum'&&game.timeMode!=='minimum'){
   const delta=Math.abs(source.minutes-game.minutes);possible+=5;earned+=delta<=15?5:delta<=30?2:0;
   if(delta<=15)reasons.push('플레이 시간이 비슷해요');
  }
  const score=100*earned/possible;
  if(score>=50)results.push({game,score,confidence:possible,reasons});
 }
 return results.sort((a,b)=>b.score-a.score||b.confidence-a.confidence||a.game.name.localeCompare(b.game.name,'ko')).slice(0,Math.max(0,Math.min(3,limit)));
}
