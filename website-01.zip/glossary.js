import {DEFAULT_TERMS} from './glossary-data.js';
import {readGlossary} from './glossary-model.js';
let GLOSSARY=DEFAULT_TERMS;
export {GLOSSARY};
const key = value => String(value ?? '').normalize('NFKC').toLocaleLowerCase('ko').replace(/[\s·・\-_/&()]/g,'');
const byName = new Map();
function rebuildIndex(){
byName.clear();
for (const term of GLOSSARY) for (const name of [term.label,...term.aliases]) {
 const normalized = key(name);
 if (byName.has(normalized) && byName.get(normalized) !== term) throw new Error(`Duplicate glossary name: ${name}`);
 byName.set(normalized,term);
}
}
rebuildIndex();
export function configureGlossary(catalog){
 let snapshot;
 try{snapshot=readGlossary(catalog);GLOSSARY=snapshot.terms;}catch(error){console.warn('용어사전을 기본 설명으로 열었어요.',error);GLOSSARY=DEFAULT_TERMS;snapshot={version:1,revision:0,terms:GLOSSARY};}
 rebuildIndex();return snapshot;
}
export const findTerm = value => byName.get(key(value));
const escape = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const question = '<svg class="bbg-chip-icon" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7.5"/><path d="M8 7.7a2.1 2.1 0 0 1 4 .8c0 1.5-2 1.6-2 3M10 14v.1"/></svg>';
export function termChip(label) {
 const term = findTerm(label);
 return term ? `<button type="button" class="bbg-term-chip" data-bbg-term="${escape(label)}" aria-label="${escape(label)} 뜻 보기" aria-haspopup="dialog">${escape(term.label!==DEFAULT_TERMS.find(value=>value.id===term.id)?.label?term.label:label)}${question}</button>` : `<span>${escape(label)}</span>`;
}
const categoryNames = {genre:'장르',mechanic:'게임 방식·규칙',theme:'배경·테마',note:'목록 표시'};
const popular = ['party','trick','hand','bidding','deckbuild','worker','set','draft','engine','bluff','cooperative','push-luck'];
export function searchTerms(query='', category='all') {
 const q=key(query);
 return GLOSSARY.filter(term => (category==='all'||term.category===category) && (!q||key([term.label,...term.aliases,term.meaning].join(' ')).includes(q)))
  .sort((a,b)=> {
   if(q) return (key(a.label)===q?-1:key(b.label)===q?1:0)||a.label.localeCompare(b.label,'ko');
   const rank = term => {const index=popular.indexOf(term.id);return index<0?popular.length:index;};
   return rank(a)-rank(b)||a.label.localeCompare(b.label,'ko');
  });
}

export function installGlossary({getGames=()=>[],openGame=()=>{},bookIcon='' }={}) {
 if(document.getElementById('glossaryDialog')) return;
 const stylesheet=document.createElement('link');stylesheet.rel='stylesheet';stylesheet.href=new URL('./glossary.css?v=20261031-terms-editor',import.meta.url).href;document.head.append(stylesheet);
 const dialog=document.createElement('dialog');dialog.id='glossaryDialog';dialog.className='bbg-glossary';dialog.setAttribute('aria-labelledby','bbg-title');dialog.setAttribute('aria-describedby','bbg-intro');
 dialog.innerHTML=`<header class="bbg-header"><p class="bbg-eyebrow">처음 만나는 말도, 쉽게</p><button type="button" class="bbg-close" data-bbg-close aria-label="용어사전 닫기"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M6 18 18 6"/></svg></button><h2 id="bbg-title" tabindex="-1">보드게임 용어사전</h2><p id="bbg-intro"></p></header><div class="bbg-body"><section id="bbg-browse"><label class="bbg-search-label" for="bbg-search">궁금한 용어 찾기</label><div class="bbg-search"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/></svg><input id="bbg-search" type="search" placeholder="파티, 트릭테이킹, 핸드관리, 비딩…" autocomplete="off" enterkeyhint="search"></div><div class="bbg-categories" role="group" aria-label="용어 종류">${[['all','전체'],['genre','장르'],['mechanic','게임 방식·규칙'],['theme','배경·테마']].map(([value,label])=>`<button type="button" data-bbg-category="${value}" aria-pressed="${value==='all'}">${label}</button>`).join('')}</div><p id="bbg-result-count" class="bbg-result-count" role="status" aria-live="polite"></p><div id="bbg-term-list" class="bbg-term-list"></div></section><section id="bbg-definition" hidden></section></div>`;
 document.body.append(dialog);
 const el=id=>document.getElementById(id);
 let category='all',query='',origin=null;
 const browse=el('bbg-browse'),definition=el('bbg-definition'),heading=el('bbg-title'),intro=el('bbg-intro');
 const show=()=>{if(!dialog.open){origin=document.activeElement;dialog.showModal();document.body.classList.add('bbg-glossary-open');}dialog.scrollTop=0;};
 function renderList(){
  const terms=searchTerms(query,category);
  el('bbg-result-count').textContent=query?`${terms.length}개의 용어를 찾았어요.`:category==='all'?`${terms.length}개 용어 · 자주 만나는 말부터 살펴보세요.`:`${terms.length}개 용어`;
  el('bbg-term-list').innerHTML=terms.length?terms.map(term=>`<button type="button" class="bbg-term-card" data-bbg-term="${escape(term.label)}" aria-haspopup="dialog"><span class="bbg-term-kind">${categoryNames[term.category]}</span><strong>${escape(term.label)}<span aria-hidden="true">↗</span></strong><span class="bbg-card-meaning">${escape(term.meaning)}</span><span class="bbg-card-more">뜻과 예시 보기 →</span></button>`).join(''):'<div class="bbg-empty"><strong>아직 등록되지 않은 용어예요.</strong><p>띄어쓰기를 바꾸거나 더 짧은 말로 검색해 보세요.</p><button type="button" data-bbg-reset>전체 용어 보기</button></div>';
  dialog.querySelectorAll('[data-bbg-category]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.bbgCategory===category)));
 }
 function showBrowse({reset=false,kind='all',focus=true}={}){
  if(reset){category=kind;query='';el('bbg-search').value='';}
  browse.hidden=false;definition.hidden=true;heading.textContent='보드게임 용어사전';intro.textContent='장르는 게임의 분위기와 특징, 메커니즘은 게임이 진행되는 방식이에요. 이름을 누르면 쉬운 예시까지 볼 수 있어요.';
  renderList();show();if(focus)heading.focus({preventScroll:true});
 }
 function showTerm(label){
  const term=findTerm(label);if(!term)return;
  browse.hidden=true;definition.hidden=false;heading.textContent=term.label;intro.textContent=categoryNames[term.category];
  const aliases=[...new Set([label,...term.aliases])].filter(name=>name!==term.label);
  const games=getGames().filter(game=>[...(game.genres||[]),...(game.mechanics||[])].some(name=>findTerm(name)===term)).slice(0,3);
  definition.innerHTML=`<button type="button" class="bbg-back" data-bbg-back>← 전체 용어 보기</button><h3 class="bbg-section-title">쉽게 말하면</h3><p class="bbg-meaning">${escape(term.meaning)}</p>${term.example?`<div class="bbg-example"><h3>이렇게 생각하면 쉬워요</h3><p>${escape(term.example)}</p></div>`:''}${aliases.length?`<p class="bbg-aliases"><strong>이렇게도 불러요</strong> ${aliases.map(escape).join(' · ')}</p>`:''}${games.length?`<div class="bbg-related"><h3 class="bbg-section-title">우리 목록에서 만나보기</h3><div>${games.map(game=>`<button type="button" data-bbg-game="${escape(game.id)}">${escape(game.name)} <span aria-hidden="true">→</span></button>`).join('')}</div></div>`:''}<p class="bbg-rule-note">같은 용어라도 세부 규칙은 게임마다 달라요.</p>`;
  show();heading.focus({preventScroll:true});
 }
 const sidebar=document.querySelector('.sidebar-bottom');
 if(sidebar){const button=document.createElement('button');button.type='button';button.dataset.bbgGlossary='all';button.setAttribute('aria-haspopup','dialog');button.innerHTML=`${bookIcon}<span>보드게임 용어사전</span>`;sidebar.prepend(button);}
 const genresEl=document.getElementById('genreChips');
 if(genresEl){const help=document.createElement('div');help.className='bbg-filter-help';help.innerHTML=`<span>장르로 취향을 찾아보세요</span><button type="button" data-bbg-glossary="all" aria-haspopup="dialog">${question} 장르·메커니즘 용어사전</button>`;genresEl.before(help);}
 document.addEventListener('click',event=>{
  const button=event.target.closest('button');if(!button)return;
  if(button.dataset.bbgTerm!==undefined){showTerm(button.dataset.bbgTerm);return;}
  if(button.dataset.bbgGlossary!==undefined){showBrowse({reset:true,kind:button.dataset.bbgGlossary});return;}
  if(button.hasAttribute('data-bbg-close')){dialog.close();return;}
  if(button.hasAttribute('data-bbg-back')){showBrowse();return;}
  if(button.dataset.bbgCategory!==undefined){category=button.dataset.bbgCategory;renderList();return;}
  if(button.hasAttribute('data-bbg-reset')){showBrowse({reset:true});return;}
  if(button.dataset.bbgGame!==undefined){dialog.close();openGame(button.dataset.bbgGame);return;}
 });
 el('bbg-search').addEventListener('input',event=>{query=event.target.value;renderList();});
 dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const box=dialog.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)dialog.close();});
 dialog.addEventListener('close',()=>{document.body.classList.remove('bbg-glossary-open');if(origin?.isConnected)origin.focus({preventScroll:true});});
}
