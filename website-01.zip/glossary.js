// Beginner-friendly descriptions, written for the club's catalog.
// Terminology checked against BGG's mechanic taxonomy and publisher rulebooks:
// https://boardgamegeek.com/boardgamemechanic/2040/hand-management
// https://boardgamegeek.com/boardgamemechanic/2012/auction-bidding
// https://thamesandkosmos.com/manuals/full/691868_Crew_Manual.pdf
// https://www.grandpabecksgames.com/products/skull-king%C2%AE
// https://www.riograndegames.com/games/dominion/
// Each row: stable ID, display name, alternative names, meaning, simple example.
const genres = [
 ['party','파티게임','파티|파티 게임|Party game','함께 웃고 대화하며 즐기기 좋은 게임이에요. 규칙이 비교적 간단한 경우가 많고, 눈치·말·순발력 등이 재미의 중심이 되기도 해요.','친구의 설명을 듣고 단어를 맞히거나, 모두 동시에 반응하며 웃는 한 판이에요.'],
 ['strategy','전략게임','전략|전략 게임|Strategy','여러 선택의 이득과 손해를 생각하며 계획을 세우는 게임이에요. 지금의 선택이 나중에 어떤 결과를 만들지 고민하는 재미가 있어요.','지금 점수를 얻을지, 다음 차례에 더 큰 이득을 줄 건물을 지을지 고르는 거예요.'],
 ['cooperative','협력게임','협력|협동|협력 전략|협력 게임|Cooperative','플레이어끼리 힘을 모아 게임이 제시한 공동 목표를 이루는 방식이에요. 보통 함께 이기거나 함께 져요.','각자 할 일을 나눠 제한 시간 안에 모두의 임무를 완수해요.'],
 ['deduction-social','추리·심리','추리 심리|추리·심리게임','단서를 모아 답을 찾거나, 다른 사람의 말과 행동에서 의도를 읽는 게임들을 묶은 장르예요.','거짓말하는 사람을 찾거나, 공개된 단서로 숨은 정답을 좁혀 가요.'],
 ['puzzle-abstract','퍼즐·추상','퍼즐 추상|퍼즐·추상게임','숫자·모양·말의 배치와 규칙 자체를 고민하는 게임들이에요. 이야기보다 문제를 풀거나 수를 읽는 재미가 중심이에요.','조각을 빈틈없이 채우거나, 내 말들을 연결할 방법을 찾아요.'],
 ['speed','순발력게임','순발력|반응 속도|Speed|Reaction','상황을 빨리 알아차리고 정확하게 반응하는 게 중요한 게임이에요. 빠르기만큼 조건을 제대로 보는 것도 중요해요.','같은 그림을 발견하면 남보다 먼저 해당 카드를 집어요.'],
 ['card-game','카드게임','카드|카드 게임|Card game','카드를 주요 도구로 사용하는 게임이에요. 카드를 어떻게 쓰느냐에 따라 가벼운 게임부터 깊은 전략게임까지 다양해요.','카드를 내거나 모으고, 카드의 숫자·그림·효과를 활용해요.'],
 ['economy-negotiation','경제·협상','경제 협상|경제·협상게임','돈과 자원을 운영하거나, 다른 사람과 거래 조건을 정하는 재미가 중심인 장르예요.','물건을 싸게 사서 비싸게 팔거나, 서로에게 필요한 자원을 교환해요.'],
 ['theme-adventure','테마·모험','테마 모험|테마·모험게임','게임 속 세계의 인물이나 상황에 몰입하며 탐험과 사건을 즐기는 장르예요.','탐험가가 되어 새로운 장소를 발견하고 사건을 해결해요.'],
 ['family','가족게임','가족|패밀리|Family','여러 연령과 경험 수준의 사람이 함께 즐기기 좋은 게임을 가리켜요. 대체로 접근하기 쉬운 규칙을 갖추지만, 난이도는 게임마다 달라요.','보드게임을 처음 해 보는 사람도 함께 규칙을 익히며 즐길 수 있어요.'],
 ['euro','유로 전략','유로전략|유로 게임|유로게임|Eurogame','자원을 효율적으로 쓰고 행동을 조합해 점수를 얻는 데 무게를 둔 게임들을 가리켜요. 모든 게임이 같은 특징을 갖는 것은 아니에요.','한정된 일꾼으로 생산·건설·교역 중 무엇을 먼저 할지 계획해요.'],
 ['abstract','추상전략','추상 전략|추상|Abstract strategy','주로 말의 위치와 정해진 규칙을 바탕으로 상대의 수를 읽는 게임이에요. 이야기나 배경보다 규칙과 배치가 중심이에요.','체스처럼 말을 어디로 옮기면 다음에 유리해질지 생각해요.'],
 ['war','워게임','워 게임|Wargame','군대나 세력의 충돌을 다루는 게임이에요. 부대 이동, 보급, 지형, 전투 등을 규칙으로 표현하며 규모와 복잡도는 다양해요.','부대를 어디로 이동시키고 어느 전선을 지킬지 정해요.'],
];
const mechanics = [
 ['hand','핸드관리','핸드 관리|핸드 매니지먼트|핸드매니지먼트|Hand management','손에 든 카드 중 무엇을 언제 쓰고 무엇을 남길지 결정하는 방식이에요. 카드의 순서와 조합, 사용할 타이밍이 중요해요.','약한 카드는 지금 쓰고, 여러 장을 함께 쓰면 강해지는 카드는 모아 두는 거예요.'],
 ['trick','트릭테이킹','트릭 테이킹|Trick-taking|Trick taking','각자 카드를 한 장씩 내어 만든 한 묶음인 ‘트릭’에서 규칙에 따라 승자를 정하는 방식이에요. 카드의 색·무늬를 따라 내거나 특별한 카드가 이기는 규칙이 붙기도 해요.','네 사람이 한 장씩 냈다면 그 네 장이 한 트릭이에요. 누가 이길지와 어떤 트릭을 가져올지 생각해요.'],
 ['bidding','비딩','입찰|Bidding|Bid','무엇을 얻기 위해 금액이나 조건을 제시하는 행동이에요. 경매에서는 가격을, 트릭테이킹에서는 자신이 이길 트릭 수를 선언하는 뜻으로도 쓰여요.','경매에서 ‘5원’을 제시하는 것도 비딩이고, 스컬 킹에서 ‘이번에는 두 번 이기겠다’고 선언하는 것도 비딩이에요.'],
 ['auction','경매','옥션|Auction|Auction / Bidding','원하는 물건이나 권리를 얻기 위해 가격이나 자원을 제시하며 경쟁하는 방식이에요. 가장 높은 가격을 제시한 사람이 가져가는 등 경매 방식에 따라 규칙이 달라요.','마음에 드는 그림에 얼마까지 낼지 정하고, 다른 사람의 제시 금액과 비교해요.'],
 ['set','세트 모으기','셋컬렉션|셋 콜렉션|셋 컬렉션|세트 컬렉션|세트모으기|Set collection','정해진 종류나 조합을 모아 점수나 보상을 얻는 방식이에요. 같은 종류를 모을 수도, 서로 다른 종류를 모을 수도 있어요.','같은 색 카드 세 장을 모으거나, 서로 다른 동물 다섯 종류를 모아 보상을 받아요.'],
 ['draft','드래프트','카드 드래프트|드래프팅|Drafting|Card drafting','여러 선택지 중 하나나 일부를 고르고, 남은 선택지를 다른 사람에게 넘기거나 남겨 두는 방식이에요.','카드 여러 장 중 한 장을 고른 뒤 나머지를 옆 사람에게 넘겨요. 공개된 카드에서 차례로 골라 가는 방식도 있어요.'],
 ['worker','일꾼 놓기','일꾼놓기|워커 플레이스먼트|Worker placement','내 일꾼 말을 행동 칸에 놓고 그 행동을 실행하는 방식이에요. 칸이 차면 다른 사람이 사용하지 못하는 게임도 많아요.','나무를 얻는 칸에 일꾼을 놓을지, 건물을 짓는 칸에 놓을지 고르는 거예요.'],
 ['deckbuild','덱빌딩','덱 빌딩|Deck building|Deckbuilding','플레이 도중 카드를 얻거나 빼면서 나만의 카드 더미인 ‘덱’을 발전시키는 방식이에요. 더 좋아진 카드들이 이후 차례에 다시 돌아와요.','처음에는 약한 카드로 시작하지만 새 카드를 사서 다음 차례의 선택지를 늘려요.'],
 ['deckconstruct','덱 구성','덱구성|Deck construction','함께 사용할 카드들의 조합을 정해 나만의 덱을 만드는 것을 뜻해요. 보통 게임 전에 준비하는 덱 구성을 말하지만, 이 목록에서는 게임 중 덱을 만드는 경우에도 쓰여요.','서로 효과가 잘 맞는 공격 카드와 지원 카드를 골라 한 덱에 넣어요. 게임 중에 덱을 키우면 덱빌딩도 함께 살펴보세요.'],
 ['engine','엔진빌딩','엔진 빌딩|Engine building','카드·건물·능력을 조합해 나중에 자원이나 점수를 더 잘 얻게 만드는 방식이에요. 자동차 엔진을 만드는 뜻은 아니에요.','나무를 얻는 건물과 나무를 점수로 바꾸는 건물을 연결해 반복해서 이득을 얻어요.'],
 ['tile','타일 놓기','타일놓기|타일 배치|Tile placement','타일을 어디에 어떤 방향으로 놓을지 결정하는 방식이에요. 옆 타일과의 연결이나 전체 모양에 따라 점수와 효과가 달라져요.','길이 이어지도록 타일을 놓거나, 같은 지형을 붙여 큰 지역을 만들어요.'],
 ['resource','자원 관리','자원관리|Resource management','돈·나무·음식처럼 사용할 수 있는 재료를 모으고, 한정된 재료를 어디에 쓸지 계획하는 방식이에요.','지금 건설에 쓸 나무를 남길지, 다른 자원으로 교환할지 결정해요.'],
 ['area','지역 장악','지역장악|Area control|Area majority','특정 지역에 내 말이나 영향력을 배치해 우위를 얻는 방식이에요. 가장 많이 차지한 사람에게 점수를 주는 등 게임마다 기준이 달라요.','한 지역에 내 말을 더 많이 놓아 그 지역의 보상을 받아요.'],
 ['influence','영향력','Influence','특정 지역·인물·집단에 대한 내 세력이나 지지의 크기를 나타내요. 영향력을 쌓아 우위나 보상을 얻는 데 사용해요.','어떤 인물에게 내 카드를 더 많이 제시해 그 인물의 지지를 얻어요.'],
 ['bluff','블러핑','블러프|Bluffing','내가 가진 정보나 의도에 대해 상대가 다르게 믿도록 유도하는 방식이에요. 말뿐 아니라 표정과 선택으로도 상대를 속일 수 있어요.','약한 카드를 들고도 자신 있게 행동해 강한 카드처럼 보이게 해요.'],
 ['negotiation','협상','Negotiation','다른 사람과 대화해 거래·협력·분배 등의 조건을 정하는 방식이에요. 약속의 효력은 게임 규칙에 따라 달라요.','‘이 자원을 줄 테니 이번에는 나를 공격하지 말아 줘’처럼 조건을 제안해요.'],
 ['scheming','협잡','Scheming','상대와 흥정하거나 견제하고, 유리한 약속을 이끌어 내는 상호작용을 가리키는 표현이에요. 정해진 하나의 규칙 이름은 아니므로 구체적인 행동은 게임마다 달라요.','거래 조건을 바꾸거나 다른 사람을 설득해 내게 유리한 상황을 만들어요.'],
 ['social','심리전','눈치게임|눈치 게임|선택 예측|Psychology','다른 사람의 생각과 다음 선택을 예상하면서 내 선택을 정하는 재미를 뜻해요.','상대가 내가 고를 숫자를 예상할 것 같아, 일부러 다른 숫자를 골라요.'],
 ['deduction','추론','추리|단서 추론|수사|Deduction','얻은 단서와 확인된 사실을 연결해 아직 모르는 답을 좁혀 가는 방식이에요.','어떤 방에는 범인이 없다는 단서를 모아 남은 장소를 찾아요.'],
 ['logic','논리','Logic','조건 사이의 관계를 따져 모순 없이 맞는 답이나 배치를 찾는 방식이에요.','‘빨강은 파랑의 왼쪽’이라는 조건을 지키면서 조각을 배치해요.'],
 ['hidden-role','정체 숨기기','숨은 정체|Hidden roles|Hidden identity','각자의 소속이나 역할이 모두에게 공개되지 않은 상태로 진행하는 방식이에요.','누가 같은 팀인지 확신할 수 없어 말과 행동을 보고 판단해요.'],
 ['mafia','마피아','마피아 게임|마녀사냥|Social deduction','숨은 소속을 가진 사람들이 대화와 추리로 상대 팀을 찾아내는 방식의 게임들을 가리켜요. 투표나 특정 역할의 능력이 쓰이기도 해요.','누가 거짓말을 하는지 토론하고 의심스러운 사람에게 투표해요.'],
 ['traitor','배신자','Traitor','협력하는 집단 안에 다른 목표를 가진 사람이 숨어 있을 수 있는 구조예요. 모든 게임에 반드시 배신자가 있는 것은 아니에요.','모두가 공동 임무를 수행하는 중 누군가는 몰래 실패시키려 해요.'],
 ['team','팀전','팀 대결|팀 게임|팀 배틀|팀 배틀 게임|Team play','플레이어들이 둘 이상의 팀으로 나뉘어 상대 팀과 겨루는 방식이에요.','같은 팀끼리 정보를 맞추고 상대 팀보다 먼저 목표를 완수해요.'],
 ['one-many','1대 다','1 대 다|One versus many','한 명이 맡은 세력이나 역할에 여러 명이 팀을 이루어 맞서는 구조예요.','한 명은 도망자를 맡고, 나머지 사람들은 함께 추적해요.'],
 ['duel','1대1 대전','1대1|1 대 1|대전|Duel','두 사람이 서로의 선택에 대응하며 겨루는 방식이에요.','내 차례에 공격할지 방어를 준비할지 정하고 상대의 대응을 살펴요.'],
 ['asymmetry','비대칭 워게임','비대칭|Asymmetric','참가 세력마다 사용할 수 있는 행동·능력·승리 조건 등이 다른 전투 중심 게임이에요.','한 세력은 넓은 땅을 차지하고, 다른 세력은 소수의 말로 특정 임무를 수행해요.'],
 ['variable-power','역할 능력','개인 능력|Variable player powers','맡은 인물이나 역할에 따라 사용할 수 있는 특별한 능력이 달라지는 방식이에요.','한 사람은 이동을 더 잘하고, 다른 사람은 자원을 더 효율적으로 모아요.'],
 ['role-select','역할 선택','Role selection','이번 차례에 맡을 역할을 골라 그 역할의 행동이나 혜택을 사용하는 방식이에요.','건설자 역할을 골라 건물을 짓거나 상인 역할로 돈을 얻어요.'],
 ['action-select','행동 선택','선택|Action selection','여러 행동 중 지금 실행할 것을 골라 진행하는 방식이에요. 가능한 행동과 선택 횟수는 게임마다 달라요.','이동·수집·건설 중 이번 차례에 할 행동을 골라요.'],
 ['simultaneous','동시 선택','동시 행동 선택|동시 행동|Simultaneous action selection','다른 사람의 선택을 확정적으로 알기 전에 각자의 선택을 정하고, 함께 공개하거나 실행하는 방식이에요.','각자 행동 카드를 뒤집어 골라 둔 뒤 동시에 공개해요.'],
 ['realtime','실시간','Real-time|Realtime','차례를 기다리기보다 시간이 흐르는 동안 행동하는 방식이에요. 제한 시간이나 빠른 판단이 중요할 수 있어요.','타이머가 끝나기 전에 각자 필요한 조각을 찾아 놓아요.'],
 ['real-coop','실시간 협력','Real-time cooperative','정해진 시간 안에 동료들과 동시에 움직이며 공동 목표를 해결하는 방식이에요.','남은 시간을 보며 필요한 재료를 나눠 맡아 함께 준비해요.'],
 ['action-points','행동점수','행동 점수|액션 포인트|Action points','내 차례에 쓸 수 있는 행동의 양이 점수로 정해져 있어요. 이동이나 수집 같은 행동에 점수를 나눠 사용해요.','행동점수 3점으로 이동 두 번과 수집 한 번을 해요. 행동별 비용이 다른 게임도 있어요.'],
 ['program','프로그래밍','행동 프로그래밍|Action programming','앞으로 할 행동을 미리 정해 두고 나중에 차례대로 실행하는 방식이에요. 코딩 지식은 필요하지 않아요.','이동 → 회전 → 전진 카드를 미리 놓고 정해진 순서로 실행해요.'],
 ['sequence','순차 실행','Sequential actions','정해 놓은 행동이나 효과를 순서대로 처리하는 방식이에요. 어떤 효과가 먼저 실행되는지가 중요할 수 있어요.','먼저 자원을 얻고, 그다음 행동에서 얻은 자원으로 건물을 지어요.'],
 ['push-luck','운 시험하기','푸시 유어 럭|푸시유어럭|Push your luck','지금 멈춰 보상을 지킬지, 실패할 위험을 감수하고 더 큰 보상을 노릴지 결정하는 방식이에요.','한 번 더 카드를 뽑으면 점수가 늘지만, 위험 카드가 나오면 이번 보상을 잃을 수 있어요.'],
 ['bet','베팅','배팅|Betting','결과를 예상해 점수나 자원을 거는 방식이에요. 예측이 맞았는지에 따라 얻거나 잃는 양이 달라져요.','어느 말이 먼저 도착할지 예상해 게임 속 칩을 걸어요.'],
 ['dice','주사위 굴리기','주사위|주사위게임|주사위 게임|주사위굴림|주사위 굴림|Dice rolling','주사위를 굴린 결과를 행동·이동·점수 등에 활용하는 방식이에요. 눈을 다시 굴리거나 결과를 조합하는 게임도 있어요.','주사위 눈을 보고 이번 차례에 이동할 거리나 사용할 행동을 정해요.'],
 ['luck','운','Randomness','카드 뽑기나 주사위처럼 미리 확정할 수 없는 결과가 게임에 영향을 주는 요소예요. 운과 판단의 비중은 게임마다 달라요.','좋은 카드가 나올 수도 있지만, 나온 카드에 맞춰 계획을 조정해야 해요.'],
 ['climb','클라이밍','Climbing|Ladder climbing','앞사람이 낸 카드나 카드 조합보다 더 강한 것을 내며 이어 가는 방식이에요. 정해진 조건에 맞춰 내거나 패스해요.','누군가 숫자 카드 두 장을 냈다면 더 강한 두 장을 내요. 손의 카드를 먼저 없애는 것이 목표인 경우가 많아요.'],
 ['rank','계급','Rank','이전 결과에 따라 지위가 나뉘고, 다음 판의 순서나 카드 교환 등에 차이가 생기는 구조예요.','이긴 사람과 진 사람이 다음 판을 시작할 때 서로 다른 혜택이나 불이익을 받아요.'],
 ['tile-piece','타일','Tiles','지도·지형·숫자 등을 표시한 조각을 뜻해요. 보통 카드보다 두껍고, 놓거나 연결하거나 조합하는 데 사용해요.','숫자 타일을 줄로 놓거나 지형 타일을 이어 지도를 만들어요.'],
 ['draw','그림 그리기','그림그리기|Drawing','그림을 그려 정보를 전달하거나 게임의 목표를 해결하는 방식이에요. 그림 실력보다 전달과 해석이 중요할 때도 많아요.','주어진 단어를 말하지 않고 그림으로 그려 동료가 맞히게 해요.'],
 ['dexterity','손재주','Dexterity','손으로 조각을 집고 옮기고 튕기는 등 실제 조작 능력이 중요한 요소예요.','다른 조각을 건드리지 않으면서 원하는 조각만 꺼내요.'],
 ['balance','균형 잡기','균형잡기|Balance','구조물이 무너지지 않도록 조각의 위치와 무게 균형을 맞추는 방식이에요.','기울어진 판 위에 조각을 하나 더 올리되 전체가 넘어지지 않게 해요.'],
 ['stack','쌓기','건물 쌓기|Stacking','조각이나 블록을 위로 올려 구조물을 만드는 방식이에요. 높이·모양·안정성 등이 목표가 될 수 있어요.','블록을 층층이 올려 정해진 모양의 탑을 만들어요.'],
 ['flick','발사','튕기기|Flicking','조각을 튕기거나 장치를 이용해 날려 목표를 맞히는 방식이에요.','힘과 방향을 조절해 말을 목표 구역 안에 보내요.'],
 ['tactile','촉각','Touch','눈으로만 확인하기보다 손으로 만져 느끼는 모양이나 감촉이 중요한 요소예요.','주머니 안의 조각을 보지 않고 만져 원하는 모양인지 판단해요.'],
 ['memory','기억력','Memory','앞서 본 정보나 위치를 기억해 활용하는 방식이에요.','뒤집힌 카드 중 같은 그림이 어디에 있었는지 기억해 두었다가 찾아요.'],
 ['pattern','패턴 인식','Pattern recognition','그림·색·숫자 사이에서 정해진 공통점이나 규칙을 알아내는 방식이에요.','세 카드가 조건에 맞는 조합인지 빠르게 확인해요.'],
 ['observe','관찰','틀린 그림 찾기|Observation','그림이나 배치를 자세히 살펴 필요한 정보나 차이점을 찾아내는 요소예요.','비슷한 두 그림에서 달라진 부분을 찾아요.'],
 ['halli-style','할리갈리식 반응','할리갈리|벨 치기','이 목록에서 ‘할리갈리’는 특정 조건을 발견하면 즉시 손을 내밀거나 반응하는 방식을 빗대어 쓴 표현이에요. 게임마다 반응해야 하는 조건은 달라요.','카드와 외친 말이 일치하는 순간, 다른 사람보다 먼저 손을 올려요.'],
 ['puzzle','퍼즐','Puzzle','정해진 조건을 만족하도록 숫자·모양·단서를 맞추는 게임 요소예요.','빈칸에 알맞은 조각을 넣거나, 조건을 만족하는 숫자를 찾아요.'],
 ['spatial','공간 지각','Spatial reasoning','조각의 모양·방향·위치를 머릿속으로 생각해 배치를 정하는 능력이 중요한 요소예요.','조각을 돌렸을 때 빈칸에 들어갈지 생각해요.'],
 ['polyomino','폴리오미노','Polyomino','정사각형 여러 개를 변끼리 이어 붙인 모양의 조각이에요. 테트리스 조각을 떠올리면 쉬워요.','ㄴ자나 긴 막대 모양 조각을 회전시켜 판을 채워요.'],
 ['numbers','숫자 조합','Number combinations','숫자를 정해진 규칙에 맞게 묶거나 늘어놓는 방식이에요.','연속된 숫자를 잇거나 같은 숫자를 여러 색으로 모아요.'],
 ['rearrange','타일 재배열','Tile rearrangement','이미 놓인 타일들을 규칙에 맞게 옮겨 새로운 조합을 만드는 방식이에요.','기존 숫자 줄을 나누고 다시 붙여 내 타일을 함께 놓아요.'],
 ['number-calc','숫자 계산','Arithmetic','숫자를 더하거나 빼고 비교하는 계산이 중요한 요소예요.','내 숫자들의 합이 정해진 목표에 가장 가까워지도록 골라요.'],
 ['number-baseball','숫자야구','숫자 야구|Bulls and cows','상대가 숨긴 숫자와 자리의 일치 여부를 단서로 정답을 찾아가는 숫자 추리 방식이에요.','숫자는 맞지만 자리가 다르다는 단서를 이용해 다음 답을 좁혀요.'],
 ['word','단어','Word game','단어의 뜻·연상·표현 등을 활용하는 요소예요.','한 단어 힌트로 동료가 여러 정답을 떠올리도록 도와요.'],
 ['word-make','낱말 만들기','Word building','주어진 글자나 음절을 조합해 유효한 낱말을 만드는 방식이에요.','손에 든 글자 조각을 이어 사전에 있는 단어를 만들어요.'],
 ['question','질문과 답변','질문|Question and answer','질문을 하고 답을 들으며 필요한 정보를 얻는 방식이에요.','가능한 질문을 골라 상대가 알고 있는 단서나 정답의 특징을 알아내요.'],
 ['twenty','스무고개','Twenty questions','정답에 대해 예·아니요 등으로 답할 수 있는 질문을 던져 범위를 좁혀 가는 방식이에요.','‘살아 있는 것인가요?’ 같은 질문으로 숨겨진 대상을 찾아요.'],
 ['limited-info','정보 제한','Communication limits','각자가 아는 정보나 서로 전달할 수 있는 정보에 제한이 있는 방식이에요.','내 카드를 그대로 말할 수 없어, 허용된 힌트 하나로 동료를 도와요.'],
 ['hidden-move','비밀 이동','Hidden movement','일부 플레이어의 위치나 이동 경로가 다른 사람에게 전부 보이지 않는 방식이에요.','도망자는 경로를 몰래 기록하고, 추적자들은 공개된 흔적으로 위치를 예상해요.'],
 ['chase','추격','Chase','도망가는 대상의 위치나 이동을 예상해 따라잡는 요소예요.','상대가 갈 수 있는 길을 막고 다음 위치를 좁혀 가요.'],
 ['move','이동','공간 이동|Movement','말이나 캐릭터의 위치를 바꾸는 행동이에요. 이동 거리·경로·비용은 게임마다 달라요.','갈림길에서 짧지만 위험한 길과 길지만 안전한 길 중 하나를 골라요.'],
 ['race','경주','경주 게임|레이싱|Racing','목표 지점에 먼저 도착하거나 정해진 목표를 먼저 달성하기 위해 경쟁하는 방식이에요.','이동 경로와 자원을 조절해 다른 사람보다 먼저 결승점에 도착해요.'],
 ['route','길 연결','길 놓기|연결|Route building','지점이나 조각 사이에 길을 만들고 이어 나가는 방식이에요.','떨어진 두 장소를 길이나 철도로 연결해 보상을 얻어요.'],
 ['maze','미로','Maze','복잡하게 연결된 길에서 가능한 이동 경로를 찾는 요소예요.','막힌 길을 피해 목표까지 이어지는 통로를 찾아요.'],
 ['territory-complete','지역 완성','Area completion','조각을 이어 특정 지역이나 구역을 규칙에 맞게 완성하는 방식이에요.','타일을 붙여 성이나 숲의 경계를 완성하고 보상을 받아요.'],
 ['rows','줄 만들기','Line making','말이나 조각을 정해진 개수·모양의 줄로 연결하는 방식이에요.','내 말 네 개를 가로나 세로로 연속해서 놓아요.'],
 ['pickup','자원 운반','Pick-up and deliver','한 장소에서 자원이나 물건을 얻어 다른 장소로 가져가 전달하는 방식이에요.','항구에서 물건을 싣고 원하는 도시까지 운반해 보상을 받아요.'],
 ['order','주문처리','주문 처리|Order fulfillment','요구된 재료나 조건을 모아 들어온 주문을 완료하는 방식이에요.','커피 주문에 필요한 재료를 모아 완성하고 다음 주문을 준비해요.'],
 ['trade','거래','Trading','다른 사람이나 게임 속 시장과 물건·돈·자원을 교환하는 행동이에요.','내게 남는 나무를 주고 지금 필요한 돌을 받아요.'],
 ['convert','자원 변환','Resource conversion','한 종류의 자원을 다른 자원이나 점수로 바꾸는 방식이에요.','밀 두 개를 음식으로 바꾸거나, 재료를 소비해 돈을 얻어요.'],
 ['shared','공유 자원','Shared resources','여러 플레이어가 함께 사용하는 한정된 자원을 뜻해요. 누군가 사용하면 다른 사람에게 남는 양도 줄어들 수 있어요.','모두가 같은 산소통을 사용하므로 한 사람이 오래 머물면 남은 사람도 영향을 받아요.'],
 ['collect','수집','카드 컬렉션|Collection','필요한 카드·조각·물건을 모으는 요소예요. 정해진 조합을 완성해 보상을 받는다면 ‘세트 모으기’와도 연결돼요.','여러 장소에서 목표에 필요한 물건을 하나씩 모아요.'],
 ['split','분할 선택','I cut, you choose','한 사람이 보상을 여러 묶음으로 나누고 다른 사람이 원하는 묶음을 고르는 방식이에요.','상대가 먼저 고를 수 있으니, 어느 묶음도 지나치게 유리하지 않도록 나눠요.'],
 ['mancala','만칼라','Mancala','한 칸의 말들을 집어 여러 칸에 하나씩 나눠 놓는 움직임을 활용하는 방식이에요. 도착한 칸이나 말의 수에 따라 행동이 달라지기도 해요.','한 칸의 말 세 개를 집어 다음 칸들에 하나씩 놓고, 마지막에 도착한 칸의 행동을 해요.'],
 ['rondel','론델','Rondel','원형 등으로 이어진 행동 칸 위에서 말을 이동시켜 행동을 고르는 방식이에요. 지금 위치에 따라 선택할 수 있는 행동이나 비용이 달라질 수 있어요.','원형 트랙에서 말을 두 칸 옮겨 그곳의 생산 행동을 해요.'],
 ['bag','주머니 빌딩','백 빌딩|Bag building','게임 중 주머니에 들어 있는 토큰의 구성을 발전시키고, 그 주머니에서 뽑은 토큰으로 행동하는 방식이에요.','원하는 토큰을 주머니에 더해 이후에 좋은 조합을 뽑을 가능성을 높여요.'],
 ['flip-write','플립 앤 라이트','플립앤라이트|Flip and write|Flip & write','카드를 공개해 나온 결과를 개인 용지나 보드에 기록하며 진행하는 방식이에요.','공개된 카드의 숫자를 내 용지의 어느 칸에 적을지 정해요.'],
 ['cardcraft','카드 크래프팅','카드크래프팅|Card crafting','한 장의 카드를 이루는 요소를 추가하거나 바꿔 카드 자체를 발전시키는 방식이에요.','투명한 카드 조각을 겹쳐 한 장의 카드에 새로운 효과를 더해요.'],
 ['chain','연쇄','콤보|Combo','하나의 행동이나 효과가 다른 효과로 이어져 연달아 혜택을 얻는 요소예요.','카드 한 장으로 자원을 얻고, 그 자원이 조건을 채워 추가 행동까지 받아요.'],
 ['combat','전투','공격과 방어|Combat','캐릭터·부대 등이 공격과 방어를 주고받으며 승패나 피해를 정하는 요소예요.','공격 카드와 방어 카드를 비교하거나 주사위로 피해를 정해요.'],
 ['attack','직접 공격','테이크 댓|Take that','다른 플레이어를 대상으로 카드나 능력을 써서 손해를 주거나 진행을 방해하는 방식이에요.','상대의 자원을 줄이거나, 준비한 행동을 못 쓰게 만들어요.'],
 ['linebattle','라인 전투','Lane battle','정해진 줄이나 경로에 유닛을 배치하고 그 경로를 따라 공격과 방어를 주고받는 방식이에요.','어느 줄에 병력을 놓아 상대의 방어를 뚫을지 결정해요.'],
 ['defense','타워 디펜스','디펜스|Tower defense','몰려오는 적이 목표 지점에 도달하지 못하도록 방어를 준비하고 막아내는 구조예요.','적이 오는 길에 방어 시설이나 캐릭터를 배치해 기지를 지켜요.'],
 ['monster','몬스터 유도','Monster movement','몬스터의 이동 규칙을 활용해 원하는 방향으로 움직이게 만드는 요소예요.','내 말의 위치를 바꿔 몬스터를 다른 경로로 보내고 안전한 길을 만들어요.'],
 ['inspect','검문','Inspection','다른 사람이 운반하거나 숨긴 물건을 확인할지 결정하는 요소예요. 확인의 비용이나 성공·실패의 보상은 게임마다 달라요.','상대의 말이 의심스러워 물건을 확인할지, 그대로 통과시킬지 고르는 거예요.'],
 ['passing','카드 전달','Card passing','카드를 다른 플레이어에게 넘기며 정보·효과·위험 등이 이동하는 방식이에요.','받은 카드를 보관할지 옆 사람에게 넘길지 정해요.'],
 ['infection','감염','Infection','상태나 소속, 위험 요소가 다른 대상에게 퍼지는 게임 요소예요. 실제 효과와 전파 조건은 게임마다 달라요.','특정 카드나 접촉으로 상태가 바뀌어 새로운 목표가 생길 수 있어요.'],
 ['vote','투표','Voting','참가자들의 표를 모아 선택이나 결과를 결정하는 방식이에요.','가장 의심스러운 사람이나 실행할 계획에 각자 한 표를 던져요.'],
 ['elimination','탈락','Player elimination','특정 조건을 만족하면 그 판의 남은 진행에서 빠지는 규칙이에요. 다시 참여하는 시점은 게임마다 달라요.','남은 생명이나 카드가 모두 없어지면 이번 판은 다른 사람들의 결과를 지켜봐요.'],
 ['secret','비밀 목표','Secret objectives','다른 사람에게 공개하지 않은 개인 목표를 달성해 보상을 얻는 구조예요.','다른 사람들은 모르지만 나는 특정 색 건물을 세 개 모으면 추가 점수를 얻어요.'],
 ['goal','목표 달성','임무|Objectives|Mission','게임이 제시한 조건을 완수하는 것이 중요한 요소예요. 목표는 개인별로 다르거나 모두가 공유할 수 있어요.','정해진 물건을 모으거나 지정된 장소에 도착하면 임무를 완수해요.'],
 ['explore','탐험','Exploration','아직 알려지지 않은 장소나 정보를 발견하며 선택지를 넓혀 가는 요소예요.','새 지형 타일을 열어 그곳의 자원이나 사건을 확인해요.'],
 ['escape','방탈출','Escape room','여러 단서와 퍼즐을 풀어 다음 단계로 나아가거나 탈출 목표를 이루는 게임이에요.','암호를 풀어 다음 카드를 열고, 얻은 정보를 이전 단서와 연결해요.'],
 ['storytell','스토리텔링','이야기 만들기|Storytelling','그림·단어·상황 등을 바탕으로 이야기를 만들거나 전달하는 요소예요.','주어진 그림들을 연결해 짧은 이야기를 만들고 다른 사람의 해석을 들어요.'],
 ['scenario','시나리오','Scenario','특정 배경·상황·목표·준비 방법을 정해 둔 한 편의 게임 구성이에요. 같은 게임도 시나리오에 따라 경험이 달라져요.','이번에는 구조 임무, 다음에는 탈출 임무처럼 시작 조건과 목표가 바뀌어요.'],
 ['campaign','캠페인','Campaign','여러 판이나 시나리오가 하나의 긴 흐름으로 연결되는 구성이에요. 이전 결과가 이어지는 정도는 게임마다 달라요.','첫 임무를 마친 뒤 이야기를 이어 다음 임무를 진행해요.'],
 ['app','앱 연동','App integration','스마트폰이나 태블릿 앱을 게임 진행에 함께 사용하는 방식이에요. 앱의 역할은 단서 제공·시간 관리·사건 처리 등 게임마다 달라요.','앱에서 사건을 확인하고 그 결과에 맞춰 보드 위 상황을 바꿔요.'],
 ['info-link','정보 연결','Connecting clues','여러 곳에서 얻은 정보를 서로 대조하고 연결해 의미를 찾는 요소예요.','인물의 말과 지도에 표시된 장소를 연결해 사건의 순서를 알아내요.'],
 ['minigame','미니게임','Mini games','한 게임 안에서 진행하는 짧고 작은 규칙의 게임이나 과제를 뜻해요.','이번에는 기억력 과제, 다음에는 순발력 과제처럼 짧게 바뀌며 진행해요.'],
 ['chess','체스','Chess','서로 다른 이동 규칙을 가진 말을 움직여 상대 킹을 피할 수 없는 공격 상태인 체크메이트로 몰아가는 추상전략 게임이에요.','폰·룩·비숍 등 말마다 다른 이동 범위를 이용해 공격과 방어를 계획해요.'],
 ['go','바둑','Go game','검은 돌과 흰 돌을 교대로 놓아 상대 돌을 포획하고 집을 확보하며 겨루는 추상전략 게임이에요.','돌들을 연결하고 둘러싸며 어느 구역을 내 집으로 만들지 생각해요.'],
 ['janggi','장기','Janggi','장기판에서 각 기물의 이동 규칙을 이용해 상대 궁을 공격하며 겨루는 추상전략 게임이에요.','차·포·마 등 기물의 움직임을 조합해 상대의 방어를 뚫어요.'],
 ['hwatu','화투','Hwatu','월별 꽃과 그림이 그려진 카드로, 여러 게임에 쓰이는 도구예요. 실제 진행과 점수 규칙은 어떤 화투 게임인지에 따라 달라요.','같은 달의 패를 맞추거나 특정 종류의 패를 모아 점수를 얻는 방식이 있어요.'],
];
const themes = [
 ['theme','테마','Theme','게임이 다루는 배경이나 소재를 뜻해요. 같은 규칙이라도 우주·중세·동물 등 어떤 테마인지에 따라 분위기가 달라져요.','카드를 모으는 규칙에 새와 서식지 이야기를 입히면 자연을 관찰하는 분위기가 돼요.'],
 ['fantasy','판타지','Fantasy','마법·용·가상의 종족처럼 현실과 다른 상상 속 세계를 배경으로 해요.','마법사가 주문을 쓰고 모험가가 몬스터를 만나는 세계예요.'],
 ['sf','SF','공상과학|Science fiction','우주·미래 기술·외계 문명 같은 공상과학을 소재로 해요.','우주선을 운용하거나 먼 행성에 새로운 문명을 세워요.'],
 ['zombie','좀비','Zombies','좀비가 등장하는 배경이나 소재예요. 살아남기·기지 지키기·탈출 등이 목표가 될 수 있어요.','한정된 식량을 나누며 좀비가 몰려오는 상황을 버텨요.'],
 ['survival','생존','서바이벌|Survival','위험과 자원 부족 속에서 살아남는 것이 중심인 소재나 목표예요.','식량을 확보하고 추위나 위협에 대비해 캐릭터를 지켜요.'],
 ['roleplay','롤플레잉','롤 플레잉|RPG|Role-playing','캐릭터의 역할을 맡아 그 입장에서 선택하고 이야기를 이어 가는 방식이에요. 전투나 성장의 비중은 게임마다 달라요.','전사나 마법사가 되어 사건에 어떻게 대응할지 함께 결정해요.'],
 ['travel','여행','Travel','장소를 방문하고 경로를 선택하는 여행의 경험을 소재로 해요.','여러 도시를 돌아다니며 방문지와 이동 순서를 정해요.'],
 ['civilization','문명 발전','문명|Civilization','사회의 기술·도시·문화 등이 성장하는 과정을 소재로 해요.','새 기술을 연구해 자원을 더 잘 생산하고 도시를 발전시켜요.'],
 ['city','도시건설','도시 건설|City building','건물과 시설을 배치해 도시를 만들어 가는 소재예요.','집과 공원, 생산 시설을 어디에 지을지 정해 도시를 키워요.'],
 ['economy','경제','경영|Economic','돈·생산·시장·운영 등 경제 활동을 다루는 소재예요.','가게를 운영하며 비용을 내고 물건을 팔아 수익을 얻어요.'],
 ['property','부동산','Real estate','땅과 건물을 사고팔거나 임대·개발하는 활동을 소재로 해요.','어느 땅에 투자하고 어떤 건물을 올릴지 결정해요.'],
 ['adventure','모험','Adventure','낯선 장소와 사건을 만나며 목표를 향해 나아가는 소재예요.','새 지역을 탐색하고 예상하지 못한 사건을 해결해요.'],
 ['sports','스포츠','Sports','실제 또는 가상의 운동 경기를 소재로 해요.','팀의 전술을 정하고 선수의 움직임이나 경기 결과를 표현해요.'],
 ['baseball','야구','Baseball','야구 경기의 공격과 수비, 선수 운영 등을 소재로 해요.','타격이나 투구를 선택하며 한 이닝의 득점을 노려요.'],
 ['horror','공포','Horror','정체불명의 위협과 긴장감, 두려움을 분위기로 삼는 소재예요.','단서를 조사하면서 다가오는 위협을 피하거나 해결해요.'],
 ['politics','정치','Politics','세력 사이의 이해관계와 권력, 의사결정 등을 소재로 해요.','다른 세력의 지지를 모아 원하는 안건을 통과시키려 해요.'],
 ['guild','길드','Guild','같은 직업이나 목적을 가진 사람들이 모인 조직을 뜻해요. 게임에서는 특정 행동·거래·혜택과 연결된 집단으로 등장해요.','상인 길드의 활동에 참여해 교역이나 생산에서 이득을 얻어요.'],
 ['livestock','목축','Animal husbandry','가축을 기르고 관리하는 활동을 소재로 해요.','동물을 들일 공간을 만들고 먹이와 번식을 관리해요.'],
];
const notes = [
 ['classification','분류 확인 중','','게임의 정확한 장르를 아직 확인하지 못했다는 목록 표시예요. 게임 방식의 이름은 아니에요.','제목이 비슷한 게임이 있다면 실제 상자의 판본을 먼저 확인해요.'],
 ['rules-check','규칙 확인 필요','','보유 게임의 정확한 규칙을 더 확인해야 한다는 목록 표시예요.','플레이 전에 동아리의 게임 설명서나 상자 구성을 확인해 주세요.'],
 ['edition-check','판본 확인 필요','','같은 이름의 여러 버전 가운데 어떤 판본을 보유했는지 더 확인해야 한다는 목록 표시예요.','인원수나 구성품이 버전에 따라 다를 수 있어 실제 상자를 살펴봐요.'],
];
const fromRows = (rows, category) => rows.map(([id,label,other,meaning,example]) => Object.freeze({id,label,aliases:Object.freeze(other ? other.split('|') : []),meaning,example,category}));
export const GLOSSARY = Object.freeze([...fromRows(genres,'genre'),...fromRows(mechanics,'mechanic'),...fromRows(themes,'theme'),...fromRows(notes,'note')]);
const key = value => String(value ?? '').normalize('NFKC').toLocaleLowerCase('ko').replace(/[\s·・\-_/&()]/g,'');
const byName = new Map();
for (const term of GLOSSARY) for (const name of [term.label,...term.aliases]) {
 const normalized = key(name);
 if (byName.has(normalized) && byName.get(normalized) !== term) throw new Error(`Duplicate glossary name: ${name}`);
 byName.set(normalized,term);
}
export const findTerm = value => byName.get(key(value));
const escape = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const question = '<svg class="bbg-chip-icon" viewBox="0 0 20 20" aria-hidden="true"><circle cx="10" cy="10" r="7.5"/><path d="M8 7.7a2.1 2.1 0 0 1 4 .8c0 1.5-2 1.6-2 3M10 14v.1"/></svg>';
export function termChip(label) {
 const term = findTerm(label);
 return term ? `<button type="button" class="bbg-term-chip" data-bbg-term="${escape(label)}" aria-label="${escape(label)} 뜻 보기" aria-haspopup="dialog">${escape(label)}${question}</button>` : `<span>${escape(label)}</span>`;
}
const categoryNames = {genre:'장르',mechanic:'게임 방식·규칙',theme:'배경·테마',note:'목록 표시'};
const popular = ['party','trick','hand','bidding','deckbuild','worker','set','draft','engine','bluff','cooperative','push-luck'];
export function searchTerms(query='', category='all') {
 const q=key(query);
 return GLOSSARY.filter(term => (category==='all'||term.category===category) && (!q||key([term.label,...term.aliases,term.meaning].join(' ')).includes(q)))
  .sort((a,b)=> {
   if(q) return (key(a.label)===q?-1:key(b.label)===q?1:0)||a.label.localeCompare(b.label,'ko');
   const rank = term => {const index=popular.indexOf(term.id);return index<0?popular.length:index;};
   return rank(a)-rank(b)||a.label.localeCompare(b.label,'ko');
  });
}

export function installGlossary({getGames=()=>[],openGame=()=>{},bookIcon='' }={}) {
 if(document.getElementById('glossaryDialog')) return;
 const stylesheet=document.createElement('link');stylesheet.rel='stylesheet';stylesheet.href=new URL('./glossary.css?v=20261031-glossary',import.meta.url).href;document.head.append(stylesheet);
 const dialog=document.createElement('dialog');dialog.id='glossaryDialog';dialog.className='bbg-glossary';dialog.setAttribute('aria-labelledby','bbg-title');dialog.setAttribute('aria-describedby','bbg-intro');
 dialog.innerHTML=`<header class="bbg-header"><p class="bbg-eyebrow">처음 만나는 말도, 쉽게</p><button type="button" class="bbg-close" data-bbg-close aria-label="용어사전 닫기"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M6 18 18 6"/></svg></button><h2 id="bbg-title" tabindex="-1">보드게임 용어사전</h2><p id="bbg-intro"></p></header><div class="bbg-body"><section id="bbg-browse"><label class="bbg-search-label" for="bbg-search">궁금한 용어 찾기</label><div class="bbg-search"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/></svg><input id="bbg-search" type="search" placeholder="파티, 트릭테이킹, 핸드관리, 비딩…" autocomplete="off" enterkeyhint="search"></div><div class="bbg-categories" role="group" aria-label="용어 종류">${[['all','전체'],['genre','장르'],['mechanic','게임 방식·규칙'],['theme','배경·테마']].map(([value,label])=>`<button type="button" data-bbg-category="${value}" aria-pressed="${value==='all'}">${label}</button>`).join('')}</div><p id="bbg-result-count" class="bbg-result-count" role="status" aria-live="polite"></p><div id="bbg-term-list" class="bbg-term-list"></div></section><section id="bbg-definition" hidden></section></div>`;
 document.body.append(dialog);
 const el=id=>document.getElementById(id);
 let category='all',query='',origin=null;
 const browse=el('bbg-browse'),definition=el('bbg-definition'),heading=el('bbg-title'),intro=el('bbg-intro');
 const show=()=>{if(!dialog.open){origin=document.activeElement;dialog.showModal();document.body.classList.add('bbg-glossary-open');}dialog.scrollTop=0;};
 function renderList(){
  const terms=searchTerms(query,category);
  el('bbg-result-count').textContent=query?`${terms.length}개의 용어를 찾았어요.`:category==='all'?`${terms.length}개 용어 · 자주 만나는 말부터 살펴보세요.`:`${terms.length}개 용어`;
  el('bbg-term-list').innerHTML=terms.length?terms.map(term=>`<button type="button" class="bbg-term-card" data-bbg-term="${escape(term.label)}" aria-haspopup="dialog"><span class="bbg-term-kind">${categoryNames[term.category]}</span><strong>${escape(term.label)}<span aria-hidden="true">↗</span></strong><span class="bbg-card-meaning">${escape(term.meaning)}</span><span class="bbg-card-more">뜻과 예시 보기 →</span></button>`).join(''):'<div class="bbg-empty"><strong>아직 등록되지 않은 용어예요.</strong><p>띄어쓰기를 바꾸거나 더 짧은 말로 검색해 보세요.</p><button type="button" data-bbg-reset>전체 용어 보기</button></div>';
  dialog.querySelectorAll('[data-bbg-category]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.bbgCategory===category)));
 }
 function showBrowse({reset=false,kind='all',focus=true}={}){
  if(reset){category=kind;query='';el('bbg-search').value='';}
  browse.hidden=false;definition.hidden=true;heading.textContent='보드게임 용어사전';intro.textContent='장르는 게임의 분위기와 특징, 메커니즘은 게임이 진행되는 방식이에요. 이름을 누르면 쉬운 예시까지 볼 수 있어요.';
  renderList();show();if(focus)heading.focus({preventScroll:true});
 }
 function showTerm(label){
  const term=findTerm(label);if(!term)return;
  browse.hidden=true;definition.hidden=false;heading.textContent=term.label;intro.textContent=categoryNames[term.category];
  const aliases=[...new Set([label,...term.aliases])].filter(name=>name!==term.label);
  const games=getGames().filter(game=>[...(game.genres||[]),...(game.mechanics||[])].some(name=>findTerm(name)===term)).slice(0,3);
  definition.innerHTML=`<button type="button" class="bbg-back" data-bbg-back>← 전체 용어 보기</button><h3 class="bbg-section-title">쉽게 말하면</h3><p class="bbg-meaning">${escape(term.meaning)}</p><div class="bbg-example"><h3>이렇게 생각하면 쉬워요</h3><p>${escape(term.example)}</p></div>${aliases.length?`<p class="bbg-aliases"><strong>이렇게도 불러요</strong> ${aliases.map(escape).join(' · ')}</p>`:''}${games.length?`<div class="bbg-related"><h3 class="bbg-section-title">우리 목록에서 만나보기</h3><div>${games.map(game=>`<button type="button" data-bbg-game="${escape(game.id)}">${escape(game.name)} <span aria-hidden="true">→</span></button>`).join('')}</div></div>`:''}<p class="bbg-rule-note">같은 용어라도 세부 규칙은 게임마다 달라요.</p>`;
  show();heading.focus({preventScroll:true});
 }
 const sidebar=document.querySelector('.sidebar-bottom');
 if(sidebar){const button=document.createElement('button');button.type='button';button.dataset.bbgGlossary='all';button.setAttribute('aria-haspopup','dialog');button.innerHTML=`${bookIcon}<span>보드게임 용어사전</span>`;sidebar.prepend(button);}
 const genresEl=document.getElementById('genreChips');
 if(genresEl){const help=document.createElement('div');help.className='bbg-filter-help';help.innerHTML=`<span>장르로 취향을 찾아보세요</span><button type="button" data-bbg-glossary="all" aria-haspopup="dialog">${question} 장르·메커니즘 용어사전</button>`;genresEl.before(help);}
 document.addEventListener('click',event=>{
  const button=event.target.closest('button');if(!button)return;
  if(button.dataset.bbgTerm!==undefined){showTerm(button.dataset.bbgTerm);return;}
  if(button.dataset.bbgGlossary!==undefined){showBrowse({reset:true,kind:button.dataset.bbgGlossary});return;}
  if(button.hasAttribute('data-bbg-close')){dialog.close();return;}
  if(button.hasAttribute('data-bbg-back')){showBrowse();return;}
  if(button.dataset.bbgCategory!==undefined){category=button.dataset.bbgCategory;renderList();return;}
  if(button.hasAttribute('data-bbg-reset')){showBrowse({reset:true});return;}
  if(button.dataset.bbgGame!==undefined){dialog.close();openGame(button.dataset.bbgGame);return;}
 });
 el('bbg-search').addEventListener('input',event=>{query=event.target.value;renderList();});
 dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const box=dialog.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)dialog.close();});
 dialog.addEventListener('close',()=>{document.body.classList.remove('bbg-glossary-open');if(origin?.isConnected)origin.focus({preventScroll:true});});
}
