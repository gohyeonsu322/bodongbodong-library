import {DEFAULT_TERMS} from './glossary-data.js';

export const DEFAULT_GENRES=['파티','전략','협력','추리·심리','퍼즐·추상','순발력','카드','경제·협상','테마·모험'];
export const termKey=value=>String(value??'').normalize('NFKC').toLowerCase().replace(/[\s·・\-_/&()]/g,'');
export const CATEGORIES={genre:'장르',mechanic:'게임 방식·규칙',theme:'배경·테마',note:'목록 표시'};
export function termIndex(terms){const index=new Map();for(const term of terms)for(const name of [term.label,...term.aliases])index.set(termKey(name),term);return index;}
export function validateTerms(input){
 if(!Array.isArray(input)||input.length>1000)throw new Error('용어는 1,000개까지 등록할 수 있어요.');
 const ids=new Set(),names=new Map();
 const text=(value,limit,title,required=false)=>{if(typeof value!=='string'||value.length>limit||(required&&!value.trim()))throw new Error(`${title}을 확인해 주세요. 최대 ${limit}자까지 입력할 수 있어요.`);return value.trim();};
 return input.map(raw=>{
  if(!raw||typeof raw!=='object'||!/^[-_a-zA-Z0-9]{1,100}$/.test(raw.id)||ids.has(raw.id))throw new Error('용어 번호가 올바르지 않거나 중복돼요.');
  ids.add(raw.id);
  if(!Object.hasOwn(CATEGORIES,raw.category))throw new Error('용어 종류를 선택해 주세요.');
  const label=text(raw.label,80,'용어 이름',true);
  if(/[\u0000-\u001f\u007f]/.test(label)||!termKey(label))throw new Error('용어 이름에는 글자나 숫자를 입력해 주세요.');
  if(!Array.isArray(raw.aliases)||raw.aliases.length>60)throw new Error('다른 표현은 60개까지 입력할 수 있어요.');
  const aliases=[...new Map(raw.aliases.map(name=>{const clean=text(name,80,'다른 표현');return [termKey(clean),clean];}).filter(([key])=>key&&key!==termKey(label))).values()];
  for(const name of [label,...aliases]){
   const key=termKey(name),used=names.get(key);
   if(used&&used.id!==raw.id)throw new Error(`‘${name}’은 이미 ‘${used.label}’에 연결되어 있어요. 다른 이름이나 표현을 입력해 주세요.`);
   names.set(key,{id:raw.id,label});
  }
  return {id:raw.id,label,category:raw.category,aliases,meaning:text(raw.meaning,3000,'설명',true),example:text(raw.example??'',3000,'예시')};
 });
}
export function readGlossary(catalog){
 const value=catalog?.glossary;
 if(value===undefined||value===null)return {version:1,revision:0,terms:DEFAULT_TERMS.map(term=>({...term,aliases:[...term.aliases]}))};
 if(value.version!==1||!Number.isSafeInteger(value.revision)||value.revision<0)throw new Error('용어사전 형식을 확인해 주세요.');
 return {version:1,revision:value.revision,terms:validateTerms(value.terms)};
}
export function canonicalName(term){
 const original=DEFAULT_TERMS.find(value=>value.id===term.id);
 if(original&&original.label===term.label){
  const legacy=DEFAULT_GENRES.find(name=>[original.label,...original.aliases].some(value=>termKey(value)===termKey(name)));
  if(legacy)return legacy;
 }
 return term.label;
}
export function genreOptions(catalog,{onlyUsed=false}={}){
 const {terms}=readGlossary(catalog),index=termIndex(terms),options=new Map();
 const add=(name,used=false)=>{
  const term=index.get(termKey(name));
  if(onlyUsed&&(!used||term?.category==='note'))return;
  const id=term?.id||'raw:'+termKey(name);
  if(!options.has(id))options.set(id,{id,label:term?canonicalName(term):name,names:[...new Set(term?[term.label,...term.aliases]:[name])]});
  const option=options.get(id);if(!option.names.includes(name))option.names.push(name);
 };
 if(!onlyUsed)for(const term of terms)if(term.category==='genre')add(term.label);
 for(const game of catalog?.games||[])for(const name of game.genres||[])add(name,true);
 const order=DEFAULT_GENRES.map(name=>index.get(termKey(name))?.id||'raw:'+termKey(name));
 return [...options.values()].sort((a,b)=>{
  const first=order.indexOf(a.id),second=order.indexOf(b.id);
  return (first<0?999:first)-(second<0?999:second)||a.label.localeCompare(b.label,'ko');
 });
}
export function linkedGames(games,term,terms){
 const index=termIndex(terms);
 return (games||[]).filter(game=>[...(game.genres||[]),...(game.mechanics||[])].some(name=>index.get(termKey(name))?.id===term.id));
}
export function changeTerm(vault,id,input,expectedRevision,renameGames=true,now=new Date().toISOString()){
 const current=readGlossary(vault.state.catalog);
 if(!Number.isSafeInteger(expectedRevision)||expectedRevision!==current.revision)throw new Error('다른 화면에서 용어를 수정했어요. 작성한 내용을 복사한 뒤 최신 목록을 불러와 주세요.');
 if(input?.id!==id||typeof renameGames!=='boolean')throw new Error('용어 정보를 다시 확인해 주세요.');
 const previous=current.terms.find(term=>term.id===id),draft={...input,aliases:Array.isArray(input.aliases)?[...input.aliases]:input.aliases};
 if(previous&&Array.isArray(draft.aliases)){
  const previousIndex=termIndex(current.terms),used=new Set();
  for(const game of [...vault.state.catalog.games,...vault.state.trash.map(entry=>entry.game)])for(const name of [...(game.genres||[]),...(game.mechanics||[])])if(previousIndex.get(termKey(name))?.id===id)used.add(name);
  draft.aliases.push(...used);
  draft.aliases=[...new Set(draft.aliases)];
 }
 const renamed=Boolean(previous&&typeof draft.label==='string'&&previous.label!==draft.label.trim());
 if(renamed&&Array.isArray(draft.aliases))draft.aliases.push(previous.label);
 const candidate=previous?current.terms.map(term=>term.id===id?draft:term):[...current.terms,draft];
 const terms=validateTerms(candidate),saved=terms.find(term=>term.id===id),next=structuredClone(vault),index=termIndex(current.terms);
 let updatedGames=0,updatedTrash=0;
 const replace=game=>{
  let changed=false;
  for(const field of ['genres','mechanics']){
   const values=(game[field]||[]).map(name=>{
    if(index.get(termKey(name))?.id!==id||name===saved.label)return name;
    changed=true;return saved.label;
   });
   game[field]=[...new Set(values)];
  }
  return changed;
 };
 if(renamed&&renameGames){
  for(const game of next.state.catalog.games)if(replace(game)){next.state.revisions[game.id]=(next.state.revisions[game.id]||0)+1;updatedGames++;}
  for(const entry of next.state.trash)if(replace(entry.game)){entry.revision++;updatedTrash++;}
 }
 next.state.catalog.glossary={version:1,revision:current.revision+1,terms};
 next.state.catalog.meta.updatedAt=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(now));
 next.state.catalog.meta.updatedAtExact=now;next.updatedAt=now;
 return {vault:next,result:{term:saved,revision:current.revision+1,updatedGames,updatedTrash}};
}
