import {normalize,difficulty,playersText,timeText,selectGames as selectRawGames,randomCandidates as randomRawCandidates,catalogFromImport} from './core.js';
import {quantityText,scoreText,photoAndDifficulty} from './member-view.js';
import {termChip,installGlossary,configureGlossary,findTerm} from './glossary.js?v=20261031-terms-editor';
import {genreOptions,termKey} from './glossary-model.js';

const $=id=>document.getElementById(id);
const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const paths={
 grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
 list:'<path d="M9 5h12M9 12h12M9 19h12"/><circle cx="4" cy="5" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="19" r="1"/>',
 search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
 people:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2m20 0v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/><circle cx="9" cy="7" r="4"/>',
 two:'<circle cx="7" cy="7" r="3"/><circle cx="17" cy="7" r="3"/><path d="M1 21v-3a5 5 0 0 1 10 0v3m2 0v-3a5 5 0 0 1 10 0v3"/>',
 clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
 heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
 dice:'<rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8" cy="8" r="1"/><circle cx="16" cy="8" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="8" cy="16" r="1"/><circle cx="16" cy="16" r="1"/>',
 arrow:'<path d="M4 12h16m-6-6 6 6-6 6"/>',
 sparkles:'<path d="m12 3 2.4 6.6L21 12l-6.6 2.4L12 21l-2.4-6.6L3 12l6.6-2.4L12 3Zm8-2v4m-2-2h4"/>',
 chess:'<path d="m8 3 8 1 3 5-4 4v4H6l1-6 4-3-3-1V3Zm-2 18h12l-1-4H7l-1 4Z"/><circle cx="13" cy="6" r=".5"/>',
 book:'<path d="M12 6c-3-3-6-3-10-2v16c4-1 7-1 10 1 3-2 6-2 10-1V4c-4-1-7-1-10 2Zm0 0v15"/>',
 info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
 help:'<circle cx="12" cy="12" r="9"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 2-3 4m0 3v.1"/>',
 share:'<path d="M12 16V3m-4 4 4-4 4 4M5 12v8a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-8"/>',
 shuffle:'<path d="m17 3 4 4-4 4m0 2 4 4-4 4M3 7h3l12 10h3M3 17h3l4-4m4-4 4-2h3"/>',
 signal:'<path d="M4 20v-4m5 4v-8m5 8V8m5 12V4"/>',
 close:'<path d="m6 6 12 12M6 18 18 6"/>',
 compare:'<path d="M8 3H3v18h5M16 3h5v18h-5M10 7l-3 3 3 3m4-2 3 3-3 3M7 10h10M7 14h10"/>',
 star:'<path d="m12 3 2.8 5.7 6.3.9-4.5 4.4 1.1 6.2-5.7-3-5.7 3 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
 edit:'<path d="m16 3 5 5-12 12-6 1 1-6L16 3Zm-2 2 5 5"/>',
 download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>',
 external:'<path d="M14 3h7v7m0-7L10 14M10 3H3v18h18v-7"/>',
 check:'<path d="m5 12 4 4L19 6"/>',
 puzzle:'<path d="M4 4h6a3 3 0 1 1 4 0h6v6a3 3 0 1 0 0 4v6h-6a3 3 0 1 1-4 0H4v-6a3 3 0 1 0 0-4V4Z"/>',
 bolt:'<path d="m13 2-9 12h7l-1 8 10-12h-7l0-8Z"/>',
 cards:'<rect x="7" y="3" width="13" height="17" rx="2"/><path d="m4 6-2 1 3 15 12-2M11 8h5m-5 4h5"/>',
 handshake:'<path d="m3 7 5-3 4 2 4-2 5 3-1 8-5 5-5-1-7-7V7Zm5-3 3 3-4 4 3 2 5-4 6 6M3 7l-2 7 4 2m16-9 2 7-3 2m-9-1 5 4m-8-1 4 2"/>',
 coin:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 4 16 4 16 0V6M4 12v6c0 4 16 4 16 0v-6"/>',
 mountain:'<path d="m2 21 7-17 6 12 3-6 5 11H2Zm5-12 2 2 2-2"/>',
 smile:'<circle cx="12" cy="12" r="9"/><path d="M8 9h.1M16 9h.1M7 14q5 7 10 0"/>',
 magnify:'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6M7 10h6m-3-3v6"/>'
};
const icon=name=>`<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name]||paths.dice}</svg>`;
const genreIcons={'파티':'smile','전략':'chess','협력':'handshake','추리·심리':'search','퍼즐·추상':'puzzle','순발력':'bolt','카드':'cards','경제·협상':'coin','테마·모험':'mountain'};
document.querySelectorAll('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon));

const STORAGE={favorites:'bodong-favorites-v1',view:'bodong-view-v1'};
function readLocal(key,fallback){try{return JSON.parse(localStorage.getItem(key))??fallback;}catch{return fallback;}}
function writeLocal(key,value){try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}}
let favorites=readLocal(STORAGE.favorites,[]);if(!Array.isArray(favorites))favorites=[];
let catalog,comparison=[],lastRandomId='';
let layout=readLocal(STORAGE.view,'grid');if(!['grid','list'].includes(layout))layout='grid';
let genreChoices=[],GENRES=[];
function vocabularySelection(games,filters){
 const same=(a,b)=>{const first=findTerm(a),second=findTerm(b);return first&&second?first.id===second.id:termKey(a)===termKey(b);};
 if(filters.search)games=games.map(game=>({...game,aliases:[...(game.aliases||[]),...[...game.genres,...game.mechanics].flatMap(name=>{const term=findTerm(name);return term?[term.label,...term.aliases]:[];})]}));
 return {games:games.filter(game=>(!filters.genre||filters.genre==='all'||game.genres.some(name=>same(name,filters.genre)))&&(filters.view!=='strategy'||game.genres.some(name=>findTerm(name)?.id==='strategy'))),filters:{...filters,genre:'all',view:filters.view==='strategy'?'all':filters.view}};
}
function selectGames(games,filters,favorites){const selection=vocabularySelection(games,filters);return selectRawGames(selection.games,selection.filters,favorites);}
function randomCandidates(games,filters,favorites){const selection=vocabularySelection(games,filters);return randomRawCandidates(selection.games,selection.filters,favorites);}
const defaultState=()=>({search:'',genre:'all',people:'',time:'',level:'',view:'all',sort:'recommended',baseOnly:false,photosOnly:false,page:1});
let state=defaultState();const PAGE_SIZE=24;
const viewNames={all:'전체 게임',beginner:'처음이라면',duo:'둘이서 한 판',group:'다같이 모여서',strategy:'전략에 진심인 날',favorites:'내가 찜한 게임'};
const viewDescriptions={beginner:'난이도 2점 미만의 가벼운 게임을 모았어요. 단독으로 플레이할 수 있는 게임부터 살펴보세요.',duo:'2명이 플레이할 수 있는 게임이에요. 2인 전용 게임을 먼저 보여드려요.',group:'6명 이상 참여할 수 있는 게임을 모았어요. 정확한 참석 인원을 선택하면 더 좁혀 볼 수 있어요.',strategy:'나만의 수를 생각하고 긴 호흡으로 몰입할 수 있는 게임이에요.',favorites:'찜한 게임은 이 브라우저에 저장돼요. 다른 기기나 브라우저와 자동으로 동기화되지 않아요.'};
const palettes=['#edf0e5','#efeee9','#edeaf0','#edf0f1','#f3ecdf','#efeeea','#f0ebe3','#e9eee6'];
const safeUrl=value=>{try{const u=new URL(value,location.href);return ['http:','https:'].includes(u.protocol)?u.href:'';}catch{return '';}};
const sourceHost=value=>{try{return new URL(safeUrl(value)).hostname;}catch{return '제품 사진 출처';}};
const safeImage=value=>{if(typeof value!=='string'||!value)return '';if(/^\/api\/images\/[a-f0-9-]{36}$/.test(value))return value;if(/^assets\/[\w./-]+$/.test(value)&&!value.includes('..'))return value;try{const u=new URL(value);return u.protocol==='https:'?u.href:'';}catch{return '';}};
const external=(url,label)=>safeUrl(url)?`<a href="${escape(safeUrl(url))}" target="_blank" rel="noopener noreferrer">${label}</a>`:'';
const getGame=id=>catalog?.games.find(g=>g.id===id);
function toast(message){$('toast').textContent=message;$('toast').classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').classList.remove('show'),3800);}
function showDialog(id){const d=$(id);if(!d.open)d.showModal();}
function closeButton(id){return `<button class="dialog-close" data-close="${id}" aria-label="닫기">${icon('close')}</button>`;}
function badge(g){return g.kind==='expansion'?'<span class="type-badge">확장판</span>':g.kind==='standalone-expansion'?'<span class="type-badge standalone">단독 플레이 가능</span>':'';}
function fallback(){return `<div class="photo-fallback">${icon('dice')}<span>사진 준비 중</span></div>`;}
function picture(g,extra=''){const src=safeImage(g.image);return src?`<img src="${escape(src)}" alt="${escape(g.name)} 제품 참고 사진" ${extra}>`:'';}
function difficultyHTML(g){const d=difficulty(g.weight);return `<span class="difficulty level-${d.level}"><span class="level-bars" aria-hidden="true">${[1,2,3,4,5].map(n=>`<i class="${n<=d.level?'on':''}"></i>`).join('')}</span><span>${d.level?d.label:'난이도 확인 중'}</span></span>`;}
function card(g,index){return `<article class="game-card" data-game-id="${escape(g.id)}"><div class="card-visual" style="background:${palettes[index%palettes.length]}"><button class="cover-button" data-open="${escape(g.id)}" aria-label="${escape(g.name)} 상세 보기">${fallback()}${picture(g,`loading="${index<4?'eager':'lazy'}" decoding="async"`)}</button>${badge(g)}<button class="save-button ${favorites.includes(g.id)?'saved':''}" data-favorite="${escape(g.id)}" aria-pressed="${favorites.includes(g.id)}" aria-label="${escape(g.name)} 찜${favorites.includes(g.id)?' 해제':'하기'}">${icon('heart')}</button></div><div class="card-content"><div class="card-genres">${g.genres.slice(0,2).map(termChip).join('')}</div><button class="card-title" data-open="${escape(g.id)}">${escape(g.name)}</button><p class="card-description">${escape(g.description||'게임의 정확한 판본과 상세 정보를 확인하고 있어요.')}</p><div class="card-facts"><span>${icon('people')}${escape(playersText(g))}</span><span>${icon('clock')}${escape(timeText(g))}</span></div><div class="card-bottom">${difficultyHTML(g)}${g.rating?`<span class="card-rating" title="평점">${icon('star')}${g.rating}</span>`:''}<label class="compare-label"><input type="checkbox" data-compare="${escape(g.id)}" ${comparison.includes(g.id)?'checked':''} aria-label="${escape(g.name)} 비교에 추가">비교</label></div></div></article>`;}
function readUrl(){
 const p=new URLSearchParams(location.search),s=defaultState();
 s.search=(p.get('q')||'').slice(0,200);s.genre=genreChoices.find(choice=>choice.names.some(name=>termKey(name)===termKey(p.get('genre'))))?.label||'all';
 for(const k of ['people','time','level']){const value=p.get(k)||'';s[k]=[...$(k==='people'?'peopleFilter':k==='time'?'timeFilter':'levelFilter').options].some(o=>o.value===value)?value:'';}
 s.view=Object.hasOwn(viewNames,p.get('view'))?p.get('view'):'all';
 s.sort=['recommended','name','time','easy','rating'].includes(p.get('sort'))?p.get('sort'):'recommended';
 s.baseOnly=p.get('base')==='1';s.photosOnly=p.get('photos')==='1';s.page=Math.max(1,Math.floor(Number(p.get('page'))||1));return s;
}
function writeUrl(){
 const p=new URLSearchParams();
 if(state.search)p.set('q',state.search);if(state.genre!=='all')p.set('genre',state.genre);
 for(const k of ['people','time','level'])if(state[k])p.set(k,state[k]);
 if(state.view!=='all')p.set('view',state.view);if(state.sort!=='recommended')p.set('sort',state.sort);
 if(state.baseOnly)p.set('base','1');if(state.photosOnly)p.set('photos','1');if(state.page>1)p.set('page',String(state.page));
 const game=new URLSearchParams(location.search).get('game');if(game)p.set('game',game);
 history.replaceState(null,'',location.pathname+(p.size?'?'+p:'')+location.hash);
}
function syncControls(){
 $('searchInput').value=state.search;$('peopleFilter').value=state.people;$('timeFilter').value=state.time;$('levelFilter').value=state.level;$('sortSelect').value=state.sort;$('baseOnly').checked=state.baseOnly;$('photosOnly').checked=state.photosOnly;
 document.querySelectorAll('[data-view]').forEach(el=>{el.classList.toggle('active',el.dataset.view===state.view);el.setAttribute('aria-current',el.dataset.view===state.view?'page':'false');});
 $('genreChips').innerHTML=`<button class="genre-chip ${state.genre==='all'?'active':''}" data-genre="all" aria-pressed="${state.genre==='all'}">${icon('grid')}전체 장르</button>`+GENRES.map(g=>`<button class="genre-chip ${state.genre===g?'active':''}" data-genre="${escape(g)}" aria-pressed="${state.genre===g}">${icon(genreIcons[g])}${escape(g)}</button>`).join('');
 $('gameGrid').classList.toggle('list-mode',layout==='list');$('gridView').classList.toggle('active',layout==='grid');$('listView').classList.toggle('active',layout==='list');$('gridView').setAttribute('aria-pressed',layout==='grid');$('listView').setAttribute('aria-pressed',layout==='list');
}
function render(){
 if(!catalog)return;syncControls();syncFavorites();
 const result=selectGames(catalog.games,state,favorites);const totalPages=Math.max(1,Math.ceil(result.length/PAGE_SIZE));state.page=Math.min(state.page,totalPages);
 $('viewTitle').textContent=state.genre!=='all'?state.genre:viewNames[state.view];
 $('resultCount').textContent=`${result.length}종`;
 const hasFilters=state.search||state.genre!=='all'||state.people||state.time||state.level||state.baseOnly||state.photosOnly||state.view!=='all';
 $('resetFilters').classList.toggle('hidden',!hasFilters);
 const description=viewDescriptions[state.view]||'';$('viewDescription').textContent=description;$('viewDescription').classList.toggle('hidden',!description);
 const pageGames=result.slice((state.page-1)*PAGE_SIZE,state.page*PAGE_SIZE);
 $('gameGrid').innerHTML=pageGames.length?pageGames.map(card).join(''):`<div class="empty-state">${icon(state.view==='favorites'?'heart':'search')}<h3>${state.view==='favorites'?'아직 찜한 게임이 없어요':'조건에 맞는 게임을 찾지 못했어요'}</h3><p>${state.view==='favorites'?'게임 사진 옆 하트를 눌러 나중에 하고 싶은 게임을 모아보세요.':'인원이나 시간 조건을 조금 넓혀 보세요. 정보가 확인되지 않은 게임은 해당 조건 검색에서 제외돼요.'}</p><button class="secondary-btn" data-action="reset-filters">${state.view==='favorites'?'전체 게임 둘러보기':'필터 초기화'}</button></div>`;
 renderPagination(totalPages);writeUrl();
}
function renderPagination(total){
 if(total<=1){$('pagination').innerHTML='';return;}
 const pages=new Set([1,total]);for(let n=Math.max(1,state.page-2);n<=Math.min(total,state.page+2);n++)pages.add(n);
 if(state.page<=3)for(let n=1;n<=Math.min(total,5);n++)pages.add(n);
 if(state.page>=total-2)for(let n=Math.max(1,total-4);n<=total;n++)pages.add(n);
 let last=0;const elements=[];
 for(const n of [...pages].sort((a,b)=>a-b)){if(n-last>1)elements.push('<span class="page-ellipsis">…</span>');elements.push(`<button data-page="${n}" class="${n===state.page?'active':''}" aria-label="${n}페이지" ${n===state.page?'aria-current="page"':''}>${n}</button>`);last=n;}
 $('pagination').innerHTML=`<button data-page="${state.page-1}" aria-label="이전 페이지" ${state.page===1?'disabled':''}><span style="display:block;transform:rotate(180deg)">${icon('arrow')}</span></button>${elements.join('')}<button data-page="${state.page+1}" aria-label="다음 페이지" ${state.page===total?'disabled':''}>${icon('arrow')}</button>`;
}
function setView(view){state={...defaultState(),view};render();if(matchMedia('(max-width:760px)').matches)$('catalog').scrollIntoView({behavior:'smooth',block:'start'});}
function syncFavorites(){
 const count=favorites.filter(id=>getGame(id)).length;$('favoriteCount').textContent=count;$('mobileFavoriteCount').textContent=count;
 document.querySelectorAll('[data-favorite]').forEach(btn=>{const saved=favorites.includes(btn.dataset.favorite);btn.classList.toggle('saved',saved);btn.setAttribute('aria-pressed',saved);const g=getGame(btn.dataset.favorite);if(btn.classList.contains('save-button'))btn.setAttribute('aria-label',`${g?.name||''} 찜${saved?' 해제':'하기'}`);else btn.innerHTML=icon('heart')+(saved?'찜했어요':'찜하기');});
}
function toggleFavorite(id){
 if(!getGame(id))return;
 const saved=favorites.includes(id);favorites=saved?favorites.filter(x=>x!==id):[...favorites,id];
 const stored=writeLocal(STORAGE.favorites,favorites);syncFavorites();if(state.view==='favorites')render();toast(stored?(saved?'찜한 게임에서 뺐어요.':'찜했어요. 이 브라우저에서 다시 볼 수 있어요.'):'이 브라우저의 저장 공간을 사용할 수 없어 이번 방문 중에만 유지돼요.');
}
function updateCompare(){
 comparison=comparison.filter(id=>getGame(id));$('compareBar').classList.toggle('hidden',!comparison.length);$('compareCount').textContent=comparison.length;$('compareNames').textContent=comparison.map(id=>getGame(id).name).join(' · ');
 document.querySelectorAll('[data-compare]').forEach(el=>el.checked=comparison.includes(el.dataset.compare));
}
function toggleCompare(id,on){if(on&&!comparison.includes(id)){if(comparison.length>=3){toast('게임은 한 번에 3종까지 비교할 수 있어요.');updateCompare();return;}comparison.push(id);}else if(!on)comparison=comparison.filter(x=>x!==id);updateCompare();}
function openDetail(id,{url=true}={}){
 const g=getGame(id);if(!g){toast('이 게임을 목록에서 찾을 수 없어요.');return;}
 const d=difficulty(g.weight),base=catalog.games.find(x=>x.name===g.baseGame);
 const gallery=[{image:g.image,source:g.imageSource,credit:g.imageCredit},...(g.gallery||[])].filter(x=>safeImage(x.image)).filter((x,i,a)=>a.findIndex(y=>y.image===x.image)===i);
 const imageCredit=gallery[0]?.credit||g.imageCredit||'제품 참고 이미지';
 $('detailContent').innerHTML=`${closeButton('detailDialog')}<div class="detail-layout"><div class="detail-left"><div class="detail-main-image" id="detailMainImage">${fallback()}${picture(g)}</div><div class="gallery-thumbnails" aria-label="게임 사진">${gallery.map((p,i)=>`<button data-gallery-index="${i}" class="${i===0?'active':''}" aria-label="${i+1}번째 사진 보기"><img src="${escape(safeImage(p.image))}" alt="${escape(g.name)} 사진 ${i+1}" loading="lazy"></button>`).join('')}</div><p class="image-credit" id="detailImageCredit">${external(gallery[0]?.source,escape(imageCredit))||escape(imageCredit)}</p><p class="image-note">${g.imageType==='club'?'동아리에서 직접 촬영한 게임 사진이에요.':g.imageType==='uploaded'?'관리자가 등록한 게임 사진이에요.':'제품의 실제 박스·구성품 참고 이미지예요.<br>동아리 소장품 직접 촬영 사진과는 달라요.'}</p></div><div class="detail-right"><p class="detail-kicker">BODONG BODONG · GAME LIBRARY</p><div class="detail-genres">${g.genres.map(termChip).join('')}${g.kind==='expansion'?'<span>확장판</span>':g.kind==='standalone-expansion'?'<span>독립형 확장</span>':''}</div><h2>${escape(g.name)}</h2>${g.english?`<p class="detail-english">${escape(g.english)}</p>`:''}<div class="detail-facts"><div><small>플레이 인원</small><strong>${escape(playersText(g))}</strong></div><div><small>플레이 시간</small><strong>${escape(timeText(g))}</strong></div><div><small>난이도</small><strong>${d.level?escape(d.label):'확인 중'}</strong></div></div>${g.kind==='expansion'?`<div class="notice purple">${icon('puzzle')} <strong>기본 게임과 함께 즐기는 확장판이에요.</strong>${base?`<br>함께 필요한 게임: <button class="text-button" data-open="${base.id}">${escape(base.name)} →</button>`:g.baseGame?`<br>기본 게임: ${escape(g.baseGame)}. 보유 구성의 호환 여부를 확인해 주세요.`:''}</div>`:''}<h3>어떤 게임인가요?</h3><p class="detail-description">${escape(g.description||'자세한 게임 정보를 준비하고 있어요.')}</p>${g.needsReview?'<div class="about-unknown">자세한 구성은 동아리 보유 상자를 확인해 주세요.</div>':''}<p class="bbg-detail-hint">장르·메커니즘 이름을 누르면 뜻과 예시를 볼 수 있어요.</p><dl class="detail-small-facts"><dt>추천 인원</dt><dd>${escape(g.best||'정보 없음')}</dd><dt>메커니즘</dt><dd><div class="mechanic-tags">${g.mechanics.length?g.mechanics.map(termChip).join(''):'확인 중'}</div></dd><dt>난이도 수치</dt><dd>${scoreText(g.weight,5)}</dd><dt>평점</dt><dd>${scoreText(g.rating,10)}</dd><dt>보유 수량</dt><dd>${quantityText(g)}</dd></dl><div class="detail-actions"><button class="secondary-btn ${favorites.includes(id)?'saved':''}" data-favorite="${id}" aria-pressed="${favorites.includes(id)}">${icon('heart')}${favorites.includes(id)?'찜했어요':'찜하기'}</button><button class="secondary-btn" data-action="share-game" data-id="${id}">${icon('share')}이 게임 공유</button><label class="secondary-btn"><input type="checkbox" data-compare="${id}" ${comparison.includes(id)?'checked':''}>비교에 추가</label></div>${photoAndDifficulty(g,external,escape)}</div></div>`;
 $('detailContent').dataset.gameId=id;$('detailContent').gallery=gallery;
 if(url){const u=new URL(location.href);u.searchParams.set('game',id);history.replaceState(null,'',u);}
 showDialog('detailDialog');
}
function setGallery(index){
 const g=getGame($('detailContent').dataset.gameId),p=$('detailContent').gallery?.[index];if(!g||!p)return;
 $('detailMainImage').innerHTML=`${fallback()}<img src="${escape(safeImage(p.image))}" alt="${escape(g.name)} 실제 제품 사진">`;
 $('detailImageCredit').innerHTML=external(p.source,escape(p.credit||'제품 참고 사진'))||escape(p.credit||'제품 참고 사진');
 document.querySelectorAll('[data-gallery-index]').forEach(el=>el.classList.toggle('active',Number(el.dataset.galleryIndex)===index));
}
function renderComparison(){
 if(comparison.length<2){toast('비교할 게임을 2종 이상 골라주세요.');return;}
 const games=comparison.map(getGame),rows=[['인원',g=>playersText(g)],['추천 인원',g=>g.best||'미기재'],['시간',g=>timeText(g)],['난이도',g=>difficulty(g.weight).label+(g.weight?' · '+g.weight+'/5':'')],['장르',g=>g.genres.join(' · ')],['한 줄 소개',g=>g.description||'상세 정보 확인 중'],['게임 구성',g=>g.kind==='expansion'?'기본판이 필요한 확장':g.kind==='standalone-expansion'?'단독 플레이 가능한 확장':'기본 게임 / 보유 구성 확인'],['평점',g=>scoreText(g.rating,10)],['보유 수량',g=>quantityText(g)]];
 $('compareContent').innerHTML=`${closeButton('compareDialog')}<div class="dialog-header"><div class="eyebrow">SIDE BY SIDE</div><h2>어느 한 판이 더 끌리나요?</h2><p>사진과 핵심 정보를 나란히 비교해 보세요. 작은 화면에서는 표를 옆으로 밀 수 있어요.</p></div><div class="compare-table-wrap"><table class="compare-table"><thead><tr class="compare-head"><th scope="col">게임</th>${games.map(g=>`<td><div class="compare-photo">${picture(g)}</div><h3>${escape(g.name)}</h3><button class="text-button" data-compare-detail="${g.id}">자세히 보기 →</button></td>`).join('')}</tr></thead><tbody>${rows.map(([label,fn])=>`<tr><th scope="row">${label}</th>${games.map(g=>`<td>${escape(fn(g))}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
 showDialog('compareDialog');
}
function guide(){
 const body=`<h3>오늘 모인 인원에 맞춰 골라보세요.</h3><ol><li><strong>인원과 시간을 선택하세요.</strong> 4명이 30분 정도 즐기려면 ‘4인’과 ‘30분 이내’를 고르면 됩니다.</li><li><strong>원하는 장르를 더해보세요.</strong> 파티, 협력, 추리·심리, 퍼즐·추상 등으로 게임을 좁힐 수 있어요.</li><li><strong>사진이나 제목을 눌러 상세 정보를 확인하세요.</strong> 게임 설명, 추천 인원, 보유 수량과 확장판 여부를 볼 수 있어요.</li><li><strong>하트로 찜하고, 최대 3개까지 비교하세요.</strong> ‘한 판 골라줘’는 현재 조건에 맞는 게임을 골라 줍니다.</li></ol><div class="guide-tip">찜한 게임은 각자의 브라우저에 저장돼요. 다음 모임에서 하고 싶은 게임을 모아 두세요.</div><h4>낯선 용어가 있다면</h4><p>장르·메커니즘 이름 옆 물음표를 누르면 쉬운 설명과 예시가 나와요. 용어사전에서는 다른 이름과 영어 표현으로도 찾아볼 수 있어요.</p><button type="button" class="bbg-guide-button" data-bbg-glossary="all" aria-haspopup="dialog">보드게임 용어사전 열기 →</button><h4>난이도 분류</h4><table><thead><tr><th>분류</th><th>난이도 수치</th></tr></thead><tbody><tr><td>입문</td><td>1.5 미만</td></tr><tr><td>초급</td><td>1.5 이상 ~ 2 미만</td></tr><tr><td>중급</td><td>2 이상 ~ 3 미만</td></tr><tr><td>고급</td><td>3 이상 ~ 4 미만</td></tr><tr><td>전문가</td><td>4 이상</td></tr></tbody></table>`;
 $('guideContent').innerHTML=`${closeButton('guideDialog')}<div class="dialog-header"><div class="eyebrow">BODONG BODONG</div><h2>이용 안내</h2><p>함께할 게임을 편하게 찾아보세요.</p></div><div class="dialog-body guide-section">${body}</div>`;
 showDialog('guideDialog');
}
function loadAdminTools(){
 try{
  const root=new URL('./',location.href);
  if(sessionStorage.getItem('bodong-admin:'+root.pathname)!=='1')return;
  $('adminTools').innerHTML='<a class="admin-public-link" href="admin/">게임 관리</a>';
  $('adminSidebar').innerHTML='<a href="admin/?panel=terms">용어 관리</a><a href="admin/?panel=guide">수정 안내</a><a href="admin/?panel=sources">정보 · 출처</a>';
 }catch{}
}
async function copyOrShare(url,title='보동보동 · 오늘 뭐 하지?'){
 if(navigator.share){try{await navigator.share({title,url});return;}catch(e){if(e.name==='AbortError')return;}}
 try{await navigator.clipboard.writeText(url);toast('공유할 주소를 복사했어요.');}
 catch{const t=document.createElement('textarea');t.value=url;t.style.cssText='position:fixed;left:-9999px;top:0';document.body.append(t);t.select();const ok=document.execCommand('copy');t.remove();if(ok)toast('공유할 주소를 복사했어요.');else{$('guideContent').innerHTML=closeButton('guideDialog')+'<div class="dialog-header"><h2>주소 복사</h2></div><div class="dialog-body"></div>';showDialog('guideDialog');const box=document.createElement('input');box.readOnly=true;box.value=url;box.setAttribute('aria-label','복사할 사이트 주소');box.style.cssText='width:100%;padding:12px;border:1px solid #dedfd8;border-radius:8px;font-size:11px';$('guideContent').querySelector('.dialog-body').prepend(box);box.focus();box.select();toast('주소를 길게 누르거나 선택해 복사해 주세요.');}}
}
function shareSite(){const u=new URL(location.href);u.hash='';if(u.searchParams.get('view')==='favorites')u.searchParams.delete('view');copyOrShare(u.href);}
function shareGame(id){const u=new URL(location.origin+location.pathname);u.searchParams.set('game',id);copyOrShare(u.href,'보동보동 · '+(getGame(id)?.name||'게임'));}
function showRandom({reroll=false}={}){
 const people=$('randomPeople')?.value??state.people,time=$('randomTime')?.value??state.time;
 let pool=randomCandidates(catalog.games,{...state,people,time,page:1},favorites);
 if(reroll&&pool.length>1)pool=pool.filter(g=>g.id!==lastRandomId);
 const g=pool.length?pool[Math.floor(Math.random()*pool.length)]:null;if(g)lastRandomId=g.id;
 $('randomContent').innerHTML=`${closeButton('randomDialog')}<div class="dialog-header"><div class="eyebrow">LET THE DICE DECIDE</div><h2>오늘은 이 한 판, 어때요?</h2><p>현재 장르·난이도·목록 조건도 함께 반영해요.</p></div><div class="random-body"><div class="random-filter"><select id="randomPeople" aria-label="추천 인원">${$('peopleFilter').innerHTML}</select><select id="randomTime" aria-label="추천 시간">${$('timeFilter').innerHTML}</select></div>${g?`<div class="random-result">${picture(g)}<h3>${escape(g.name)}</h3><div class="random-facts"><span>${escape(playersText(g))}</span><span>${escape(timeText(g))}</span><span>${difficulty(g.weight).label}</span></div><p>${escape(g.description)}</p></div>`:'<div class="random-result"><h3>조건을 조금 넓혀 볼까요?</h3><p>현재 조건에 맞는 독립 플레이 가능한 게임이 없어요. 인원이나 시간을 바꿔보거나 목록의 필터를 초기화해 주세요.</p></div>'}<p class="random-subtext">기본판이 필요한 확장판과 판본 확인이 필요한 게임은 추천에서 제외해요. 실제 플레이 시간은 설명과 준비 시간에 따라 늘어날 수 있어요.</p><div class="guide-button-row"><button class="secondary-btn" data-action="reroll">${icon('shuffle')}다시 골라줘</button>${g?`<button class="primary-btn" data-random-detail="${g.id}">이 게임 자세히 ${icon('arrow')}</button>`:'<button class="secondary-btn" data-action="random-reset">전체 조건에서 고르기</button>'}</div></div>`;
 $('randomPeople').value=people;$('randomTime').value=time;showDialog('randomDialog');
}
function updateCounts(){
 $('titleCount').textContent=catalog.games.length;$('navCount').textContent=catalog.games.length;$('updateText').textContent='목록 정리 '+String(catalog.meta.updatedAt||'2026-10-30').replaceAll('-','.');
 const wings=catalog.games.find(g=>g.name==='윙스팬'),cascadia=catalog.games.find(g=>g.name==='캐스캐디아');
 if(wings){const scene=wings.gallery?.find(x=>x.type==='components'||x.type==='play')||wings.gallery?.[0];const src=safeImage(scene?.image||wings.image);if(src)$('heroPhoto').src=src;}
 if(cascadia&&safeImage(cascadia.image))$('heroBox').src=safeImage(cascadia.image);
 syncFavorites();
}
document.addEventListener('click',event=>{
 const target=event.target.closest('button,a');if(!target)return;
 if(target.dataset.close){$(target.dataset.close).close();return;}
 if(target.dataset.view){setView(target.dataset.view);return;}
 if(target.dataset.genre){state.genre=target.dataset.genre;state.page=1;render();return;}
 if(target.dataset.open){openDetail(target.dataset.open);return;}
 if(target.dataset.favorite){toggleFavorite(target.dataset.favorite);return;}
 if(target.dataset.page){state.page=Number(target.dataset.page);render();$('results-toolbar')?.scrollIntoView();$('catalog').scrollIntoView({behavior:'smooth'});return;}
 if(target.dataset.galleryIndex!==undefined){setGallery(Number(target.dataset.galleryIndex));return;}
 if(target.dataset.compareDetail){$('compareDialog').close();openDetail(target.dataset.compareDetail);return;}
 if(target.dataset.randomDetail){$('randomDialog').close();openDetail(target.dataset.randomDetail);return;}
 const action=target.dataset.action;if(!action)return;
 if(action==='guide')guide();
 else if(action==='random')showRandom();
 else if(action==='reroll')showRandom({reroll:true});
 else if(action==='random-reset'){state=defaultState();render();$('randomDialog').close();showRandom();}
 else if(action==='share')shareSite();
 else if(action==='share-game')shareGame(target.dataset.id);
 else if(action==='compare')renderComparison();
 else if(action==='clear-compare'){comparison=[];updateCompare();}
 else if(action==='reset-filters'){state=defaultState();render();}
 else if(action==='retry')location.reload();
});
document.addEventListener('change',event=>{
 const el=event.target;if(el.matches('[data-compare]'))toggleCompare(el.dataset.compare,el.checked);
 if(el.id==='randomPeople'||el.id==='randomTime')showRandom();
});
document.addEventListener('error',event=>{if(event.target.tagName==='IMG'){const img=event.target;if(img.id==='heroPhoto'||img.id==='heroBox'){img.style.visibility='hidden';return;}img.remove();}},true);
document.querySelectorAll('dialog').forEach(d=>{
 d.addEventListener('click',event=>{if(event.target===d){const rect=d.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)d.close();}});
});
$('detailDialog').addEventListener('close',()=>{const u=new URL(location.href);u.searchParams.delete('game');history.replaceState(null,'',u);});
$('searchInput').addEventListener('input',()=>{state.search=$('searchInput').value;state.page=1;clearTimeout(window.searchTimer);window.searchTimer=setTimeout(render,130);});
for(const [id,key] of [['peopleFilter','people'],['timeFilter','time'],['levelFilter','level'],['sortSelect','sort'],['baseOnly','baseOnly'],['photosOnly','photosOnly']])$(id).addEventListener('change',()=>{state[key]=id==='baseOnly'||id==='photosOnly'?$(id).checked:$(id).value;state.page=1;render();});
$('resetFilters').addEventListener('click',()=>{state=defaultState();render();});
$('gridView').addEventListener('click',()=>{layout='grid';writeLocal(STORAGE.view,layout);render();});
$('listView').addEventListener('click',()=>{layout='list';writeLocal(STORAGE.view,layout);render();});
document.addEventListener('keydown',event=>{if(event.key==='/'&&!event.metaKey&&!event.ctrlKey&&!/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)&&!document.querySelector('dialog[open]')){event.preventDefault();$('searchInput').focus();}});
window.addEventListener('popstate',()=>{if(!catalog)return;state=readUrl();render();const id=new URLSearchParams(location.search).get('game');if(id)openDetail(id,{url:false});else $('detailDialog').close();});

async function init(){
 try{
  const response=await fetch('./catalog.json',{cache:'no-store'});if(!response.ok)throw new Error('게임 목록 응답을 받지 못했어요.');
  catalog=catalogFromImport(await response.json());
  catalog.glossary=configureGlossary(catalog);genreChoices=genreOptions(catalog,{onlyUsed:true});GENRES=genreChoices.map(choice=>choice.label);
  state=readUrl();updateCounts();render();
  const id=new URLSearchParams(location.search).get('game');if(id)openDetail(id,{url:false});
 }catch(error){$('gameGrid').innerHTML=`<div class="empty-state">${icon('info')}<h3>목록을 불러오지 못했어요.</h3><p>잠시 후 다시 시도해 주세요. 문제가 계속되면 동아리 운영진에게 알려주세요.</p><button class="primary-btn" data-action="retry">다시 불러오기</button></div>`;$('resultCount').textContent='연결 확인 필요';console.error(error);}
}
installGlossary({getGames:()=>catalog?.games||[],openGame:openDetail,bookIcon:icon('book')});
init();
loadAdminTools();
